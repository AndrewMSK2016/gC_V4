from dataclasses import dataclass
from json import load
from os import environ
from typing import List

from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.client.telegram import TelegramAPIServer
from dotenv import load_dotenv
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from openai import OpenAI

load_dotenv()


@dataclass
class Gigachat:
    client_id: str
    client_secret: str


@dataclass
class TelegramUserAgent:
    api_id: int
    api_hash: str
    device_model: str
    system_version: str
    app_version: str
    lang_code: str


@dataclass
class YookassaConfig:
    shop_id: int
    secret_key: str


@dataclass
class TelegramBotAPI:
    enabled: bool
    api_base: str
    is_local: bool


@dataclass
class Proxy:
    proxy_type: str
    host: str
    port: int
    login: str
    password: str


@dataclass
class Config:
    tg_token: str
    admin_id: int
    gigachat: Gigachat
    cost: int
    yookassa: YookassaConfig
    bot: Bot
    dp: Dispatcher
    bot_username: str
    custom_botapi: dict
    proxies: List[Proxy]
    scheduler = AsyncIOScheduler()
    chatgpt: OpenAI


def load_config(filename: str) -> Config:
    data = load(open(filename, encoding="utf-8"))
    data["gigachat"] = Gigachat(**data["gigachat"])
    data["yookassa"] = YookassaConfig(**data["yookassa"])
    if data["custom_botapi"]["enabled"]:
        session = AiohttpSession(
            api=TelegramAPIServer.from_base(
                data["custom_botapi"]["api_base"],
                is_local=data["custom_botapi"]["is_local"],
            )
        )
        data["bot"] = Bot(token=data["tg_token"], parse_mode="HTML", session=session)
    else:
        data["bot"] = Bot(
            token=data["tg_token"],
            parse_mode="HTML",
        )
    data["dp"] = Dispatcher(storage=MemoryStorage())

    # parse proxy
    proxies = []
    for proxy in data["proxies"]:
        proxies.append(Proxy(**proxy))
    data["proxies"] = proxies

    # setup openai
    data["chatgpt"] = OpenAI(
        base_url="https://api.proxyapi.ru/openai/v1", api_key=data["chatgpt_api_key"]
    )
    del data["chatgpt_api_key"]

    return Config(**data)


def calc_final_amount(accounts: int, channels: int, month: int):
    return ((100 * accounts) + (50 * channels)) * month


config = load_config("config.json" if not environ.get("DEBUG") else "debug-config.json")

model_names = {"gigachat": "🟢 GigaChat", "chatgpt": "⚫️ ChatGPT"}
