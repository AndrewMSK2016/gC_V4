import os
from asyncio import get_event_loop
from logging import basicConfig, INFO, info
from os import listdir, remove, system
from threading import Thread

import sentry_sdk
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.client.telegram import TelegramAPIServer
from aiogram.types import BotCommand, BotCommandScopeDefault
from sqlalchemy.orm import create_session

from config import config
from database import engine, Account, UserAgent, AccountProxy
from handlers import (
    start,
    acc_manage,
    add_account,
    add_channel,
    ch_manage,
    ch_promps,
    commenting,
    posting,
    setup_menu,
    userbot_handlers,
    cancel_sub,
    userbot_actions,
    post
)
from middlewares import MediaMiddleware
from utils import run_tasks

sentry_sdk.init(
    dsn="https://37c1bfa4fdbe54c02f2b7654d4757707@o4505509226676224.ingest.us.sentry.io/4506987533434880",
    traces_sample_rate=1.0,
    profiles_sample_rate=1.0,
)


async def main():
    session = AiohttpSession(
        api=TelegramAPIServer.from_base("http://localhost:8081", is_local=True)
    )
    db_session = create_session(engine)
    # load accounts
    for session in listdir("accounts/sessions"):
        if (
                not session.endswith(".session")
                or session.endswith(".session-journal")
                or ".ds_store" in session.lower()
        ):
            continue
        account = (
            db_session.query(Account)
            .filter_by(file_id=session.replace(".session", ""))
            .first()
        )
        if not account:
            continue
        if not account.useragent:
            continue
        if os.name == "nt":
            thread = Thread(
                target=lambda: system(
                    f".\\venv\Scripts\python userbot/core.py {session.replace('.session', '')} {account.useragent} {account.proxy if account.proxy else -1}"
                )
            )
        else:
            thread = Thread(
                target=lambda: system(
                    f"venv/bin/python3 userbot/core.py {session.replace('.session', '')} {account.useragent} {account.proxy if account.proxy else -1}"
                )
            )
        thread.start()
        info(f"Loaded account {session}")

    await run_tasks()
    info("Stared cron tasks")

    config.dp.include_routers(
        post,
        start,
        acc_manage,
        add_channel,
        add_account,
        ch_manage,
        ch_promps,
        commenting,
        posting,
        setup_menu,
        cancel_sub,
        userbot_handlers,
        userbot_actions,
    )
    config.dp.message.middleware.register(MediaMiddleware())
    commands = [BotCommand(command="start", description="Перезапустить бота")]
    await config.bot.set_my_commands(commands, BotCommandScopeDefault())
    await config.dp.start_polling(config.bot)


if __name__ == "__main__":
    basicConfig(level=INFO)
    loop = get_event_loop()
    try:
        loop.run_until_complete(main())
    except KeyboardInterrupt:
        for file in listdir("accounts/sessions"):
            if file.endswith(".session-journal"):
                remove(f"accounts/sessions/{file}")
