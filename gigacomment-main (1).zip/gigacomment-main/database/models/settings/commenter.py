from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, BigInteger
from sqlalchemy.orm import mapped_column

from ...core import Base


class CommenterSettings(Base):
    __tablename__ = "commenter_settings"
    id = Column(Integer, primary_key=True, autoincrement=True)
    channel_id = mapped_column(Integer, ForeignKey("channels.id"))
    chat_id = Column(BigInteger, default=0, server_default="0")
    latency = Column(String, default="10-60", server_default="10-60")
    random = Column(Integer, default=0, server_default="0")
    model = Column(String, default="gigachat", server_default="gigachat")

    only_react_short_posts = Column(Boolean, default=True, server_default="True")
    answer_replies = Column(Boolean, default=True, server_default="True")
    comment_time = Column(String, server_default="8-20", default="8020")

    comment_prompt = Column(
        String,
        default="Напиши комментарий для поста: {}",
        server_default="Напиши комментарий для поста: {}",
    )
    answer_prompt = Column(
        String,
        default="Напиши ответ на комментарий: {}",
        server_default="Напиши ответ на комментарий: {}",
    )

    daily_comments = Column(Integer, default=0, server_default="0")
    comments_count = Column(Integer, default=0, server_default="0")
    reply_count = Column(Integer, default=0, server_default="0")
    daily_reply_count = Column(Integer, default=0, server_default="0")
