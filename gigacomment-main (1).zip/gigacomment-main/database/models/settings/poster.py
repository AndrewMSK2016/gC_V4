from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, BigInteger, ARRAY
from sqlalchemy.orm import mapped_column

from ...core import Base


class PosterSettings(Base):
    __tablename__ = "poster_settings"
    id = Column(Integer, primary_key=True, autoincrement=True)
    channel_id = mapped_column(Integer, ForeignKey("channels.id"))
    to_channel_id = Column(BigInteger)
    to_channel_link = Column(String, default="", server_default="")
    model = Column(String, default="gigachat", server_default="gigachat")

    latency = Column(Integer, default=20, server_default="20")
    generate_by_first = Column(Boolean, default=False, server_default="False")
    user_stop_words = Column(Boolean, default=True, server_default="True")
    link = Column(String, server_default=None, nullable=True)

    prompt = Column(
        String,
        default="Перефразируй данный текст: {}",
        server_default="Перефразируй данный текст: {}",
    )
    stop_words = Column(ARRAY(String), server_default="{}")

    daily_posted = Column(Integer, default=0, server_default="0")
    posted_count = Column(Integer, default=0, server_default="0")
