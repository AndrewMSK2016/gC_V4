from sqlalchemy import Column, String, Integer

from ..core import Base


class UserAgent(Base):
    __tablename__ = "useragents"
    id = Column(Integer, autoincrement=True, primary_key=True)
    device_model = Column(String, nullable=False)
    system_version = Column(String, nullable=False)
    app_version = Column(String, nullable=False)
    lang_code = Column(String, nullable=False)
