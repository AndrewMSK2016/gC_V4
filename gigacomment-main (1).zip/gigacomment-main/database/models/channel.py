from sqlalchemy import Column, Integer, String, ForeignKey, Boolean
from sqlalchemy.orm import mapped_column
from sqlalchemy.types import BigInteger

from ..core import Base


class Channel(Base):
    __tablename__ = "channels"
    id = Column(Integer, primary_key=True, autoincrement=True)
    mode = Column(String, default="comments", server_default="comments")
    user = mapped_column(ForeignKey("users.id"), nullable=False)
    account = mapped_column(ForeignKey("accounts.id"), nullable=False)
    channel_link = Column(String, nullable=False)
    channel_id = Column(BigInteger, nullable=False)
    enabled = Column(Boolean, nullable=False, default=True, server_default="True")
    comments_open = Column(Boolean, nullable=False, default=True, server_default="True")
