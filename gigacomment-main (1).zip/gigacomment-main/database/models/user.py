from datetime import datetime

from sqlalchemy import Boolean, Column, BigInteger, Integer, DateTime

from ..core import Base


class User(Base):
    __tablename__ = "users"
    id = Column(BigInteger, primary_key=True)
    account_count = Column(Integer, default=1, server_default="1")
    channels_count = Column(Integer, default=0, server_default="0")
    month = Column(Integer, default=1, server_default="1")
    notification_id = Column(BigInteger)
    is_payed = Column(Boolean, nullable=False, default=False, server_default="False")
    end_date = Column(DateTime, default=datetime.now(), nullable=True)
