from sqlalchemy import Boolean, Column, Integer, ForeignKey, String, BigInteger
from sqlalchemy.orm import mapped_column

from ..core import Base


class AccountProxy(Base):
    __tablename__ = "proxies"
    id = Column(Integer, primary_key=True, autoincrement=True)
    proxy_type = Column(String)
    host = Column(String)
    port = Column(Integer)
    login = Column(String, nullable=True, default="", server_default="")
    password = Column(String, nullable=True, default="", server_default="")


class Account(Base):
    __tablename__ = "accounts"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user = mapped_column(ForeignKey("users.id"), nullable=False)
    file_id = Column(String, nullable=False)
    mode = Column(String, nullable=False)
    useragent = mapped_column(ForeignKey("useragents.id"), nullable=False)
    telegram_id = Column(BigInteger, nullable=False)
    proxy = mapped_column(ForeignKey("proxies.id"), nullable=True)
