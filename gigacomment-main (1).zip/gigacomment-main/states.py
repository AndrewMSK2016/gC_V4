from aiogram.fsm.state import State, StatesGroup


class UserStates(StatesGroup):
    ACCOUNT_DETAILS = State()
    ENTER_ACCOUNT_COUNT = State()
    ENTER_CHANNEL_COUNT = State()
    ENTER_MONTH_COUNT = State()
    ENTER_NOTIFICATION_ID = State()

    ENTER_ACCOUNTS_ZIP = State()

    ENTER_CHANNELS = State()

    ENTER_COMMENT_LATENCY = State()

    ENTER_POSTING_LATENCY = State()
    ENTER_POSTING_LINK = State()
    ENTER_POSTING_TARGET = State()
    ENTER_POSTING_STOP_WORDS = State()
    ENTER_RESEND_MESSAGE_FROM_USERBOT = State()
    ENTER_USERBOT_REPLY = State()

    ENTER_PROMPT = State()

    STARTUP_SETUP = State()

    ENTER_NEW_ACCOUNT_DATA = State()

    ENTER_POSTS = State()
    WAIT_MEDIAGROUP = State()

