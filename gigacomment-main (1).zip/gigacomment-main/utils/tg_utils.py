import base64
import logging
import os
import shutil
import sqlite3
import struct
from dataclasses import dataclass
from logging import info
from pathlib import Path
from random import choice
from uuid import uuid4
from os import remove
from typing import Any, Literal, BinaryIO

import python_socks
import socks
from aiogram.types import Message

from opentele.td import TDesktop
from opentele.api import UseCurrentSession, APIData, API
from pyrogram.enums import ParseMode
from pyrogram.raw import functions, base
from pyrogram.raw.types import InputUserSelf
from pyrogram.storage import Storage, FileStorage
from pyrogram import Client as PyroClient
from pyrogram.types import User
from telethon import TelegramClient
from telethon.sessions import StringSession
from telethon.tl import types
from sqlalchemy.orm import create_session

from database import Account, AccountProxy, engine, UserAgent
from config import TelegramUserAgent
from .shit import device_models, system_versions, app_versions
from userbot.funcs import Client


@dataclass
class TelegramAccount:
    first_name: str
    last_name: str
    username: str
    id: int
    phone_number: str
    bio: str


class TelegramTools:
    def __init__(self, account_id: str):
        self.account_id = account_id

    @staticmethod
    def get_file_id(account_id: int) -> str:
        session = create_session(engine)
        account = session.get(Account, account_id)
        return account.file_id

    def make_duplicate_session(self) -> str:
        shutil.copy(
            f"accounts/sessions/{self.account_id}.session",
            f"accounts/sessions/{self.account_id}-2.session",
        )
        logging.info("Made duplicated session")
        return f"accounts/sessions/{self.account_id}-2"

    def delete_duplicate_session(self) -> bool:
        try:
            os.remove(f"accounts/sessions/{self.account_id}-2.session")
        except:
            return False
        return True

    async def change_name(self, name: str) -> bool:
        session = create_session(engine)
        account = session.query(Account).filter_by(file_id=self.account_id).first()
        if not account:
            raise ValueError("Account is not found")
        proxy = session.get(AccountProxy, account.proxy)
        useragent = session.get(UserAgent, account.useragent)
        session_path = self.make_duplicate_session()
        async with PyroClient(
            device_model=useragent.device_model,
            system_version=useragent.system_version,
            api_id=2040,
            api_hash="b18441a1ff607e10a989891a5462e627",
            app_version=useragent.app_version,
            lang_code=useragent.lang_code,
            name=session_path,
            proxy=(
                {
                    "scheme": proxy.proxy_type,
                    "hostname": proxy.host,
                    "port": proxy.port,
                    "username": proxy.login,
                    "password": proxy.password,
                }
                if proxy
                else None
            ),
        ) as client:
            try:
                is_success = await client.update_profile(first_name=name)
            except:
                return False
        self.delete_duplicate_session()
        return is_success

    async def change_surname(self, surname: str) -> bool:
        session = create_session(engine)
        account = session.query(Account).filter_by(file_id=self.account_id).first()
        if not account:
            raise ValueError("Account is not found")
        proxy = session.get(AccountProxy, account.proxy)
        useragent = session.get(UserAgent, account.useragent)
        session_path = self.make_duplicate_session()
        async with PyroClient(
            device_model=useragent.device_model,
            system_version=useragent.system_version,
            api_id=2040,
            api_hash="b18441a1ff607e10a989891a5462e627",
            app_version=useragent.app_version,
            lang_code=useragent.lang_code,
            name=session_path,
            proxy=(
                {
                    "scheme": proxy.proxy_type,
                    "hostname": proxy.host,
                    "port": proxy.port,
                    "username": proxy.login,
                    "password": proxy.password,
                }
                if proxy
                else None
            ),
        ) as client:
            try:
                is_success = await client.update_profile(last_name=surname)
            except:
                return False
        self.delete_duplicate_session()
        return is_success

    async def change_username(self, username: str) -> bool:
        session = create_session(engine)
        account = session.query(Account).filter_by(file_id=self.account_id).first()
        if not account:
            raise ValueError("Account is not found")
        proxy = session.get(AccountProxy, account.proxy)
        useragent = session.get(UserAgent, account.useragent)
        session_path = self.make_duplicate_session()
        async with PyroClient(
            device_model=useragent.device_model,
            system_version=useragent.system_version,
            api_id=2040,
            api_hash="b18441a1ff607e10a989891a5462e627",
            app_version=useragent.app_version,
            lang_code=useragent.lang_code,
            name=session_path,
            proxy=(
                {
                    "scheme": proxy.proxy_type,
                    "hostname": proxy.host,
                    "port": proxy.port,
                    "username": proxy.login,
                    "password": proxy.password,
                }
                if proxy
                else None
            ),
        ) as client:
            try:
                is_success = await client.set_username(username)
            except:
                return False
        self.delete_duplicate_session()
        return is_success

    async def change_bio(self, bio: str):
        session = create_session(engine)
        account = session.query(Account).filter_by(file_id=self.account_id).first()
        if not account:
            raise ValueError("Account is not found")
        proxy = session.get(AccountProxy, account.proxy)
        useragent = session.get(UserAgent, account.useragent)
        session_path = self.make_duplicate_session()
        async with PyroClient(
            device_model=useragent.device_model,
            system_version=useragent.system_version,
            api_id=2040,
            api_hash="b18441a1ff607e10a989891a5462e627",
            app_version=useragent.app_version,
            lang_code=useragent.lang_code,
            name=session_path,
            proxy=(
                {
                    "scheme": proxy.proxy_type,
                    "hostname": proxy.host,
                    "port": proxy.port,
                    "username": proxy.login,
                    "password": proxy.password,
                }
                if proxy
                else None
            ),
        ) as client:
            try:
                is_success = await client.update_profile(bio=bio)
            except:
                return False
        self.delete_duplicate_session()
        return is_success

    async def change_avatar(
        self, binary: BinaryIO, avatar_type: Literal["photo", "video"]
    ):
        session = create_session(engine)
        account = session.query(Account).filter_by(file_id=self.account_id).first()
        if not account:
            raise ValueError("Account is not found")
        proxy = session.get(AccountProxy, account.proxy)
        useragent = session.get(UserAgent, account.useragent)
        session_path = self.make_duplicate_session()
        async with PyroClient(
            device_model=useragent.device_model,
            system_version=useragent.system_version,
            api_id=2040,
            api_hash="b18441a1ff607e10a989891a5462e627",
            app_version=useragent.app_version,
            lang_code=useragent.lang_code,
            name=session_path,
            proxy=(
                {
                    "scheme": proxy.proxy_type,
                    "hostname": proxy.host,
                    "port": proxy.port,
                    "username": proxy.login,
                    "password": proxy.password,
                }
                if proxy
                else None
            ),
        ) as client:
            try:
                if avatar_type == "photo":
                    is_success = await client.set_profile_photo(photo=binary)
                elif avatar_type == "video":
                    is_success = await client.set_profile_photo(video=binary)
            except:
                return False
        self.delete_duplicate_session()
        return is_success

    async def send_message(
        self, chat_id: int, message: Message, binary: BinaryIO = None
    ):
        session = create_session(engine)
        account = session.query(Account).filter_by(file_id=self.account_id).first()
        if not account:
            raise ValueError("Account is not found")
        logging.info("Found account")
        proxy = session.get(AccountProxy, account.proxy)
        useragent = session.get(UserAgent, account.useragent)
        logging.info("Got proxy and useragent for account")
        session_path = self.make_duplicate_session()
        async with PyroClient(
            device_model=useragent.device_model,
            system_version=useragent.system_version,
            api_id=2040,
            api_hash="b18441a1ff607e10a989891a5462e627",
            app_version=useragent.app_version,
            lang_code=useragent.lang_code,
            name=session_path,
            proxy=(
                {
                    "scheme": proxy.proxy_type,
                    "hostname": proxy.host,
                    "port": proxy.port,
                    "username": proxy.login,
                    "password": proxy.password,
                }
                if proxy
                else None
            ),
        ) as client:
            try:
                if message.video:
                    await client.send_video(
                        chat_id=chat_id,
                        video=binary,
                        caption=message.caption,
                        caption_entities=message.caption_entities,
                        has_spoiler=message.has_media_spoiler,
                        width=message.video.width,
                        height=message.video.height,
                    )
                elif message.photo:
                    await client.send_photo(
                        chat_id=chat_id,
                        photo=binary,
                        caption=message.caption,
                        caption_entities=message.caption_entities,
                        has_spoiler=message.has_media_spoiler,
                    )
                elif message.document:
                    await client.send_document(
                        chat_id=chat_id,
                        document=binary,
                        caption=message.caption,
                        caption_entities=message.caption_entities,
                    )
                elif message.location:
                    await client.send_location(
                        chat_id=chat_id,
                        latitude=message.location.latitude,
                        longitude=message.location.longitude,
                    )
                elif message.venue:
                    await client.send_venue(
                        chat_id=chat_id,
                        latitude=message.venue.location.latitude,
                        longitude=message.venue.location.longitude,
                        title=message.venue.title,
                        address=message.venue.address,
                    )
                elif message.voice:
                    await client.send_voice(
                        chat_id=chat_id,
                        voice=binary,
                    )
                elif message.video_note:
                    await client.send_video_note(
                        chat_id=chat_id,
                        video_note=binary,
                    )
                elif message.audio:
                    await client.send_audio(
                        chat_id=chat_id,
                        audio=binary,
                        caption=message.caption,
                        caption_entities=message.caption_entities,
                        duration=message.audio.duration,
                        performer=message.audio.performer,
                        title=message.audio.title,
                        file_name=message.audio.file_name,
                    )
                else:
                    await client.send_message(
                        chat_id=chat_id,
                        text=message.html_text,
                        parse_mode=ParseMode.HTML,
                    )
                return True
            except Exception as e:
                logging.error(f"Error when sending a normal text message: {e}")
                return False

    async def get_account_info(self) -> TelegramAccount:
        session = create_session(engine)
        account = session.query(Account).filter_by(file_id=self.account_id).first()
        if not account:
            raise ValueError("Account is not found")
        logging.info("Found account")
        proxy = session.get(AccountProxy, account.proxy)
        useragent = session.get(UserAgent, account.useragent)
        logging.info("Got proxy and useragent for account")
        session_path = self.make_duplicate_session()
        async with PyroClient(
            device_model=useragent.device_model,
            system_version=useragent.system_version,
            api_id=2040,
            api_hash="b18441a1ff607e10a989891a5462e627",
            app_version=useragent.app_version,
            lang_code=useragent.lang_code,
            name=session_path,
            proxy=(
                {
                    "scheme": proxy.proxy_type,
                    "hostname": proxy.host,
                    "port": proxy.port,
                    "username": proxy.login,
                    "password": proxy.password,
                }
                if proxy
                else None
            ),
        ) as client:
            me_short: User = await client.get_me()
            me: base.users.UserFull = await client.invoke(
                functions.users.GetFullUser(id=InputUserSelf())
            )
            tg_client = TelegramAccount(
                phone_number=me_short.phone_number,
                first_name=me_short.first_name,
                last_name=me_short.last_name,
                username=me_short.username,
                id=me_short.id,
                bio=me.full_user.about,
            )
        self.delete_duplicate_session()
        return tg_client


def pack_to_string(
    dc_id: int, auth_key: bytes, user_id: int, is_bot: bool = False
) -> str:
    try:
        bytes_result: bytes = struct.pack(
            Storage.SESSION_STRING_FORMAT,
            dc_id,
            None,
            auth_key,
            user_id,
            is_bot,
        )
    except struct.error:
        bytes_result: bytes = struct.pack(
            Storage.OLD_SESSION_STRING_FORMAT_64,
            dc_id,
            None,
            auth_key,
            user_id,
            is_bot,
        )
    encode_result: bytes = base64.urlsafe_b64encode(bytes_result)
    decode_result: str = encode_result.decode()
    result: str = decode_result.rstrip("=")
    return result


def generate_random_data():
    return TelegramUserAgent(
        api_id=6,
        api_hash="eb06d4abfb49dc3eeb1aeb98ae0f581e",
        device_model=choice(device_models),
        system_version=choice(system_versions),
        app_version=choice(app_versions),
        lang_code="en",
    )


async def tdata_to_pyrogram(
    tdata_path: str, proxy: AccountProxy
) -> tuple[int, int, None] | None | tuple[str, Any, APIData]:
    account_id = str(uuid4())

    # convert from tdata to telethon
    try:
        tdesk = TDesktop(tdata_path)
        if not tdesk.isLoaded():
            return 0, 0, None
    except Exception as e:
        return 0, 0, None
    if not tdesk.isLoaded():
        return 0, 0, None
    useragent = API.TelegramDesktop(
        api_id=2040,
        api_hash="b18441a1ff607e10a989891a5462e627",
    )
    try:
        client = await tdesk.ToTelethon(
            session=f"accounts/telethon/{account_id}.session",
            flag=UseCurrentSession,
            api=APIData(
                api_id=useragent.api_id,
                api_hash=useragent.api_hash,
                device_model=useragent.device_model,
                system_version=useragent.system_version,
                app_version=useragent.app_version,
                lang_code=useragent.lang_code,
                lang_pack=useragent.lang_pack,
            ),
        )
    except:
        return 0, 0, None
    if not client.UserId:
        return 0, 0, None
    dc_id = tdesk.accounts[0].MainDcId
    auth_key = tdesk.accounts[0].authKey.key
    await client.disconnect()
    info("Converted to telethon format")

    session_str = pack_to_string(
        user_id=client.UserId, is_bot=False, dc_id=dc_id, auth_key=auth_key
    )

    # create pyrogram client
    async with Client(
        name=f"accounts/sessions/{account_id}",
        session_string=session_str,
        api_id=tdesk.api.api_id,
        api_hash=tdesk.api.api_hash,
        device_model=useragent.device_model,
        system_version=useragent.system_version,
        app_version=useragent.app_version,
        lang_code=useragent.lang_code,
        proxy=(
            {
                "scheme": proxy.proxy_type,
                "hostname": proxy.host,
                "port": proxy.port,
                "username": proxy.login,
                "password": proxy.password,
            }
            if proxy
            else None
        ),
    ) as client:
        client.storage = FileStorage(
            f"accounts/sessions/{account_id}.session", Path("accounts/sessions")
        )
        client.storage.conn = sqlite3.Connection(
            f"accounts/sessions/{account_id}.session"
        )  # sqlite3.OperationalError: not exist
        client.storage.create()  # sqlite3.OperationalError: already exists

        # save data
        user_data = await client.get_me()
        if not user_data:
            return 0, 0, None
        await client.storage.dc_id(dc_id)
        await client.storage.test_mode(False)
        await client.storage.auth_key(auth_key)
        await client.storage.user_id(user_data.id)
        await client.storage.date(0)
        await client.storage.is_bot(False)
        # Save session
        await client.storage.save()
        info("written session to pyrogram session")

        # check session
        me = await client.get_me()
        if not me.id:
            return

        info(f"Logged as @{me.username} (ID: {me.id})")
        info("Converted")
        return account_id, me.id, useragent


def prepare_userbots_ids():
    session = create_session(engine)
    accounts = session.query(Account).all()
    return [account.telegram_id for account in accounts]
