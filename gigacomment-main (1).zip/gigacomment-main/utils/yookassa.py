import uuid

from aiohttp import ClientSession, BasicAuth

from config import config


class Yookassa:
    def __init__(self):
        self._session = ClientSession(
            auth=BasicAuth(
                login=str(config.yookassa.shop_id), password=config.yookassa.secret_key
            )
        )

    async def create_payment(self, amount: int):
        idempotence_key = str(uuid.uuid4())
        response = await self._session.post(
            url="https://api.yookassa.ru/v3/payments",
            headers={
                "Idempotence-Key": idempotence_key,
                "Content-Type": "application/json",
            },
            json={
                "amount": {"value": float(amount), "currency": "RUB"},
                "confirmation": {
                    "type": "redirect",
                    "return_url": "https://t.me/t1wk4",
                },
            },
        )
        data = await response.json()
        return data["id"], data["confirmation"]["confirmation_url"]

    async def check_payment(self, payment_id: str):
        idempotence_key = str(uuid.uuid4())
        response = await self._session.get(
            url=f"https://api.yookassa.ru/v3/payments/{payment_id}",
            headers={"Idempotence-Key": idempotence_key},
        )
        data = await response.json()
        return data["status"] == "succeeded"
