from sqlalchemy.orm import create_session

from config import config
from database import (
    engine,
    CommenterSettings,
    Account,
    UserAgent,
    Channel,
    PosterSettings,
)
from userbot.funcs import check_account


async def reset_daily_commenter_settings():
    session = create_session(engine)
    commenters = session.query(CommenterSettings).all()
    for commenter in commenters:
        commenter.daily_comments = 0
        commenter.daily_reply_count = 0
        session.commit()
    session.close()


async def reset_daily_poster_settings():
    session = create_session(engine)
    posters = session.query(PosterSettings).all()
    for poster in posters:
        poster.daily_posted = 0
        session.commit()
    session.close()


async def check_all_accounts():
    session = create_session(engine)
    accounts = session.query(Account).all()
    for account in accounts:
        useragent = session.get(UserAgent, account.useragent)
        is_active = await check_account(account.file_id, useragent)
        if not is_active:
            channels = session.query(Channel).filter_by(account=account.id).all()
            if channels:
                for channel in channels:
                    poster = (
                        session.query(PosterSettings)
                        .filter_by(channel_id=channel.id)
                        .first()
                    )
                    if poster:
                        session.delete(poster)
                        session.commit()
                    commenter = (
                        session.query(CommenterSettings)
                        .filter_by(channel_id=channel.id)
                        .first()
                    )
                    if commenter:
                        session.delete(commenter)
                        session.commit()
                    session.delete(channel)
                    session.commit()
            session.delete(account)
            session.commit()
            session.close()
            await config.bot.send_message(
                chat_id=account.user,
                text=f"""<b>⚠️ Важное уведомление!</b>
                
🤖 Один из ваших аккаунтов (#{account.id}) стал невалидным, поэтому мы удалили все настройки, связанные с ним.""",
            )


async def run_tasks():
    config.scheduler.add_job(
        reset_daily_commenter_settings,
        "cron",
        day="*",
        week="*",
        hour=0,
        minute=1,
        second=0,
    )
    config.scheduler.add_job(
        reset_daily_poster_settings,
        "cron",
        day="*",
        week="*",
        hour=0,
        minute=1,
        second=0,
    )
    config.scheduler.add_job(
        check_all_accounts, "cron", day="*", week="*", hour="*", minute=0, second=0
    )
    config.scheduler.start()
