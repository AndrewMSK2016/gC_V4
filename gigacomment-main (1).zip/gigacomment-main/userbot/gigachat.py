import ssl
from uuid import uuid4

from aiohttp import ClientSession, TCPConnector


class Gigachat:
    def __init__(self):
        self.token = ""
        ssl_ctx = ssl.create_default_context(cafile="russian_trusted_root_ca.cer")
        conn = TCPConnector(ssl_context=ssl_ctx)
        self._session = ClientSession(connector=conn)

    async def auth(self, client_id: str, client_secret: str):
        # authorization = b64encode(f"{client_id}:{client_secret}".encode())
        authorization = "YzM1ZTYwMmYtODk4ZS00ODZkLWEzOGUtZTM2Y2RlNTM4YTUzOjg2ZDE3NWZlLWJjZTctNGMxMC05MDljLTQ4NzlhMWM0NTQ4OA=="
        # todo fix
        response = await self._session.post(
            url="https://ngw.devices.sberbank.ru:9443/api/v2/oauth",
            headers={
                "Authorization": f"Basic {authorization}",
                "RqUID": str(uuid4()),
                "Content-Type": "application/x-www-form-urlencoded",
            },
            data={"scope": "GIGACHAT_API_PERS"},
        )
        print(response.status)
        data = await response.json()
        if response.status == 200:
            self.token = data["access_token"]
            return data["access_token"]

    async def get_answer(self, prompt: str):
        response = await self._session.post(
            url="https://gigachat.devices.sberbank.ru/api/v1/chat/completions",
            headers={"Authorization": f"Bearer {self.token}"},
            json={
                "model": "GigaChat-Pro",
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 1,
            },
        )
        if response.status == 200:
            data = await response.json()
            return data["choices"][0]["message"]["content"]
