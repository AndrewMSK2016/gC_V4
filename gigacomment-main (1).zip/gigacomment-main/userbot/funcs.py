from shutil import copy

from pyrogram import Client
from pyrogram.errors import ChatRestricted, ChatInvalid, ChannelPrivate
from sqlalchemy.orm import create_session
from aiohttp import ClientSession

from database import engine, Account, User, UserAgent, AccountProxy
from config import load_config


class Client(Client):
    async def authorize(self) -> User:
        return False


async def join_channel(chat_link: str, account_id: str, ua: UserAgent):
    print(account_id)
    session = create_session(engine)
    account = session.query(Account).filter_by(file_id=account_id).first()
    proxy = session.get(AccountProxy, account.proxy)
    session.close()
    copy(
        f"accounts/sessions/{account_id}.session",
        f"accounts/sessions/{account_id}-2.session",
    )
    async with Client(
        device_model=ua.device_model,
        system_version=ua.system_version,
        api_id=2040,
        api_hash="b18441a1ff607e10a989891a5462e627",
        app_version=ua.app_version,
        lang_code=ua.lang_code,
        name=f"accounts/sessions/{account_id}-2",
        proxy=(
            {
                "scheme": proxy.proxy_type,
                "hostname": proxy.host,
                "port": proxy.port,
                "username": proxy.login,
                "password": proxy.password,
            }
            if proxy
            else None
        ),
    ) as client:
        ok = True
        try:
            if not "+" in chat_link:
                chat_link = chat_link.replace("https://t.me/", "")
            chat_preview = await client.get_chat(chat_link)
            if not chat_preview:
                return False, "invalid", 0
            chat = await client.join_chat(chat_link)
            chat = await client.get_chat(chat.id)

            # get linked chat info
            if not chat.linked_chat:
                return ok, "ok", chat.id, False
            return ok, "ok", chat.id, True
        except ChatRestricted:
            return False, "banned", 0, False
        except ChatInvalid:
            return False, "invalid", 0, False
        except ChannelPrivate:
            return False, "private", 0, False
        except Exception as e:
            return False, e, 0, False
        except:
            return False, "unknown", 0, False


async def get_user_username(account_id: str, ua: UserAgent):
    session = create_session(engine)
    account = session.query(Account).filter_by(file_id=account_id).first()
    proxy = session.get(AccountProxy, account.proxy)
    session.close()
    async with Client(
        device_model=ua.device_model,
        system_version=ua.system_version,
        api_id=2040,
        api_hash="b18441a1ff607e10a989891a5462e627",
        app_version=ua.app_version,
        lang_code=ua.lang_code,
        name=f"accounts/sessions/{account_id}",
        proxy=(
            {
                "scheme": proxy.proxy_type,
                "hostname": proxy.host,
                "port": proxy.port,
                "username": proxy.login,
                "password": proxy.password,
            }
            if proxy
            else None
        ),
    ) as client:
        me = await client.get_me()
        return me.username


async def get_channel_info(chat): ...


async def check_account(account_id: str, ua: UserAgent):
    session = create_session(engine)
    account = session.query(Account).filter_by(file_id=account_id).first()
    proxy = session.get(AccountProxy, account.proxy)
    session.close()
    print(account_id)
    copy(
        f"accounts/sessions/{account_id}.session",
        f"accounts/sessions/{account_id}-2.session",
    )
    try:
        async with Client(
            device_model=ua.device_model,
            system_version=ua.system_version,
            api_id=2040,
            api_hash="b18441a1ff607e10a989891a5462e627",
            app_version=ua.app_version,
            lang_code=ua.lang_code,
            name=f"accounts/sessions/{account_id}-2",
            proxy=(
                {
                    "scheme": proxy.proxy_type,
                    "hostname": proxy.host,
                    "port": proxy.port,
                    "username": proxy.login,
                    "password": proxy.password,
                }
                if proxy
                else None
            ),
        ) as client:
            me = await client.get_me()
            if not me.id:
                return False
            return True
    except Exception as e:
        print(e)
        return False


async def send_notification(account_id: str, text: str):
    session = create_session(engine)
    account = session.query(Account).filter_by(file_id=account_id).first()
    user = session.get(User, account.user)
    session.close()
    config = load_config("config.json")
    async with ClientSession() as session:
        response = await session.post(
            url=f"https://api.telegram.org/bot{config.tg_token}/sendMessage",
            data={"chat_id": user.notification_id, "text": text, "parse_mode": "HTML"},
        )
        await session.close()
    text = await response.text()
    print(text)
    if response.status != 200:
        return False
    return True
