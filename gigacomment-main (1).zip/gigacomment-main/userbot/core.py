import urllib
from asyncio import sleep
from random import randint
from sys import path, argv
from os import getcwd

path.append(getcwd())
path.append(getcwd())

from aiohttp import ClientSession
from pyrogram import filters
from pyrogram.types import Message, InputMediaPhoto
from pyrogram.enums import ChatType
from sqlalchemy.orm import create_session

from gigachat import Gigachat
from database import engine, UserAgent
from database.models.settings import PosterSettings, CommenterSettings
from database.models.accounts import Account, AccountProxy
from database.models.user import User
from database.models.channel import Channel
from config import config
from funcs import Client

session = argv[1]
useragent_id = argv[2]
proxy_id = argv[3]

db_session = create_session(engine)
proxy = db_session.get(AccountProxy, proxy_id)
useragent = db_session.get(UserAgent, useragent_id)
db_session.close()

client = Client(
    device_model=useragent.device_model,
    system_version=useragent.system_version,
    api_id=2040,
    api_hash="b18441a1ff607e10a989891a5462e627",
    app_version=useragent.app_version,
    lang_code=useragent.lang_code,
    name=getcwd() + f"/accounts/sessions/{session}",
    proxy=(
        {
            "scheme": proxy.proxy_type,
            "hostname": proxy.host,
            "port": proxy.port,
            "username": proxy.login,
            "password": proxy.password,
        }
        if proxy
        else None
    ),
)
sent_mediagroups = []

# init sentry
import sentry_sdk

sentry_sdk.init(
    dsn="https://ec9694d20aeafa0a940cc645dca6653e@o4505509226676224.ingest.us.sentry.io/4506993305190400",
    traces_sample_rate=1.0,
    profiles_sample_rate=1.0,
)


async def send_notification(account_id: str, text: str):
    session = create_session(engine)
    account = session.query(Account).filter_by(file_id=account_id).first()
    user = session.get(User, account.user)
    session.close()
    async with ClientSession() as session:
        response = await session.post(
            url=f"https://api.telegram.org/bot{config.tg_token}/sendMessage",
            data={"chat_id": user.notification_id, "text": text, "parse_mode": "HTML"},
        )
        await session.close()
    if response.status != 200:
        text = await response.text()
        print(text)
        return False
    return True


# @client.on_message(filters.reply)
async def handle_replies(client, message: Message):
    try:
        if message.reply_to_message and message.reply_to_message.from_user.is_self:
            session = create_session(engine)
            comment_settings = (
                session.query(CommenterSettings)
                .filter_by(chat_id=message.chat.id)
                .first()
            )
            if comment_settings:
                channel = session.get(Channel, comment_settings.channel_id)
                account = session.get(Account, channel.account)
                if not comment_settings.answer_replies:
                    session.close()
                    return
            else:
                session.close()
                return
            print("try to answer")
            session.close()

            gigachat = Gigachat()
            original_text = message.text if message.text else message.caption
            if comment_settings.model == "gigachat":
                gigachat = Gigachat()
                await gigachat.auth(
                    client_id=config.gigachat.client_id,
                    client_secret=config.gigachat.client_secret,
                )
                answer = await gigachat.get_answer(
                    comment_settings.comment_prompt.format(
                        message.text if message.text else message.caption
                    )
                )
            else:
                answer = (
                    config.chatgpt.chat.completions.create(
                        model="gpt-3.5-turbo",
                        messages=[{"role": "user", "content": original_text}],
                    )
                    .choices[0]
                    .text
                )
            try:
                await message.reply(answer)
                await send_notification(
                    account.file_id,
                    f"""<b>🔔 Новое сообщение от комментера</b>

👤 Ваш бот с ID <code>{account.file_id[0:8]}</code> оставил ответ на <a href="{message.link}">ответ на комментарий</a> в канале <code>#{message.chat.id}</code>

🔗 Сообщение, на которое бот ответил: <blockquote>{message.reply_to_message.text}</blockquote>

📝 Ответ бота: <blockquote>{answer}</blockquote>""",
                )
            except:
                await message.chat.leave()
                await send_notification(
                    account.file_id,
                    f"""<b>🔔 Новое сообщение от комментера</b>

👤 Ваш бот с ID <code>{account.file_id[0:8]}</code> вышел из чата при попытке оставить <a href="{message.link}">ответ на комментарий</a> в канале <code>#{message.chat.id}</code>

<b>💡 Советуем перенастроить параметры канала, чтобы другой бот оставлял комментарии. Если вы думаете, что это ошибка, то проигнорируйте данное сообщение</b>""",
                )
    except:
        ...


def strip_all_entities(text):
    new_string = ""
    for i in text.split():
        s, n, p, pa, q, f = urllib.parse.urlparse(i)
        if s and n:
            pass
        elif i[:1] == "@":
            pass
        elif i[:1] == "#":
            new_string = new_string.strip() + " " + i[1:]
        else:
            new_string = new_string.strip() + " " + i
    return new_string


async def userbot_poster(client: Client, message: Message, poster: PosterSettings):
    if message.media_group_id in sent_mediagroups:
        return
    print("userbot for posting!")
    session = create_session(engine)
    channel = session.query(Channel).filter_by(channel_id=message.chat.id).first()
    session.close()
    if not channel.enabled:
        return
    print("Parsed settings")

    print("Sleeping...")
    await sleep(poster.latency * 60)

    try:
        await client.send_message(
            chat_id=config.bot_username,
            text=f"/newpost {channel.id}"
        )
    except:
        await client.unblock_user(config.bot_username)
        await send_notification(
            account_id=channel.account,
            text=f"""<b>⚠️ Важное уведомление от постинга!</b>
            
Аккаунт главного бота внесен в черный список юзербота""")
        await client.send_message(
            chat_id=config.bot_username,
            text=f"/newpost {channel.id}"
        )

    if message.media_group_id:
        media_group = await client.get_media_group(
            chat_id=message.chat.id,
            message_id=message.id
        )
        await client.send_message(
            chat_id=config.bot_username,
            text=f"/postmediagroup {channel.id}"
        )
        for msg in media_group:
            await msg.copy(
                chat_id=config.bot_username
            )
        await client.send_message(
            chat_id=config.bot_username,
            text="/postmediagroupend"
        )
    else:
        await message.copy(
            chat_id=config.bot_username
        )


@client.on_message(filters.private)
async def handle_pm(client: Client, message: Message):
    if message.from_user.username == config.bot_username:
        return await message.copy(chat_id="me")

    print("handled pm")
    db_session = create_session(engine)
    account = db_session.query(Account).filter_by(file_id=session).first()
    db_session.close()

    await client.send_message(
        chat_id=config.bot_username, text=f"/newpm {account.id} {message.from_user.id}"
    )
    await message.copy(chat_id=config.bot_username)


@client.on_message()
async def userbot_comments(client: Client, message: Message):
    print("Handle! Start working...")
    try:
        session = create_session(engine)
        channel = session.query(Channel).filter_by(channel_id=message.chat.id).first()
        account = session.get(Account, channel.account)
    except:
        return
    if channel:
        comment_settings = (
            session.query(CommenterSettings).filter_by(channel_id=channel.id).first()
        )
        poster = session.query(PosterSettings).filter_by(channel_id=channel.id).first()
    elif channel is None or channel.enabled is False:
        session.close()
        return
    session.close()

    if channel.mode == "posting":
        print("Detected posting settings...")
        await userbot_poster(client, message, poster)
        return
    elif not channel.comments_open:
        return await send_notification(
            account.file_id,
            f"""<b>🔔 Новое сообщение от комментера</b>

👤 Ваш бот с ID <code>{account.file_id[0:8]}</code> не совершил действие по комментированию, поскольку комментирование в <a href="{message.link}">сообщении</a> закрыто""",
        )

    # react
    try:
        if not comment_settings.only_react_short_posts:
            if not message.text or len(message.text) < 50 or len(message.caption) < 50:
                await send_notification(
                    account.file_id,
                    f"""<b>🔔 Новое сообщение от комментера</b>

👤 Ваш бот с ID <code>{account.file_id[0:8]}</code> оставил реакцию под <a href="{message.link}">последним постом в канале</a> <code>#{message.chat.id}</code>""",
                )
                await message.react("👍")
                print("Reacted")
                return
    except:
        ...

    # rand
    random_cap = comment_settings.random
    if random_cap == 1:
        if randint(1, 3) != 1:
            return
    elif random_cap == 2:
        if randint(1, 3) in range(1, 3):
            return

    print("Random on our side! Start sleeping...")
    # lat
    latency = comment_settings.latency
    if comment_settings.latency.isdigit():
        await sleep(int(latency))
    else:
        min_lat, max_lat = map(int, latency.split("-"))
        await sleep(randint(min_lat, max_lat))

    print("Slept. Go to comment.")

    original_text = message.text if message.text else message.caption
    if comment_settings.model == "gigachat":
        gigachat = Gigachat()
        await gigachat.auth(
            client_id=config.gigachat.client_id,
            client_secret=config.gigachat.client_secret,
        )
        answer = await gigachat.get_answer(
            comment_settings.comment_prompt.format(
                message.text if message.text else message.caption
            )
        )
    else:
        answer = (
            config.chatgpt.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": original_text}],
            )
            .choices[0]
            .message.content
        )
    print("Recieved answer")
    if message.chat.type == ChatType.CHANNEL:
        chat = await client.get_chat(message.chat.id)
        comments_chat = chat.linked_chat.id
        message = await client.get_discussion_message(chat.id, message.id)
        try:
            await client.send_message(
                chat_id=comments_chat, text=answer, reply_to_message_id=message.id
            )
            print("sent")

            # add count to comments stats
            session = create_session(engine)
            commenter = session.get(CommenterSettings, comment_settings.id)
            commenter.daily_comments += 1
            commenter.comments_count += 1
            session.commit()
            session.close()

            # send notification
            await send_notification(
                account.file_id,
                f"""<b>🔔 Новое сообщение от комментера</b>

👤 Ваш бот с ID <code>{account.file_id[0:8]}</code> отослал новое сообщение в <a href="{message.chat.invite_link}">канал</a> под <a href="{message.link}">последним постом в канале</a>. 

💠 Исходное сообщение: <blockquote>{original_text}</blockquote>

📝 <b>Сгенерированное сообщение:</b> <blockquote>{answer}</blockquote>""",
            )
        except:
            await message.chat.leave()
            print("banned")
            await send_notification(
                account.file_id,
                f"""<b>🔔 Новое сообщение от комментера</b>

👤 Ваш бот с ID <code>{account.file_id[0:8]}</code> вышел из <a href="{message.chat.invite_link}">канала</a> при попытке оставить комментарий к сообщению под <a href="{message.link}">последним постом в канале</a>

💠 Исходное сообщение: <blockquote>{original_text}</blockquote>

📝 <b>Сгенерированное сообщение:</b> <blockquote>{answer}</blockquote>""",
            )
        if comment_settings.answer_replies:
            try:
                await client.join_chat(comments_chat)
                await send_notification(
                    account.file_id,
                    f"""<b>🔔 Новое сообщение от комментера</b>

👤 Ваш бот с ID <code>{account.file_id[0:8]}</code> зашел в чат <a href="{message.chat.invite_link}">канала</a>, чтобы отслеживать ответы на его сообщения.""",
                )
            except:
                await send_notification(
                    account.file_id,
                    f"""<b>🔔 Новое сообщение от комментера</b>

👤 Ваш бот с ID <code>{account.file_id[0:8]}</code> заблокирован в чате <a href="{message.chat.invite_link}">канала</a>. Смените аккаунт""",
                )

            session = create_session(engine)
            comment_settings = session.get(CommenterSettings, comment_settings.id)
            comment_settings.chat_id = comments_chat

            # add count to reply count field
            comment_settings.daily_reply_count += 1
            comment_settings.reply_count += 1

            session.commit()
            session.close()


client.run()
