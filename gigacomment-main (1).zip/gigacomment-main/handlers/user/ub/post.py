import asyncio

from aiogram import Router, Bot
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import Message
from sqlalchemy.orm import create_session

from config import config
from database import engine, Channel, PosterSettings
from states import UserStates
from userbot.gigachat import Gigachat

router = Router()


@router.message(Command("newpost"))
async def new_post(message, state: FSMContext):
    channel_id = int(message.text.split()[1])
    await state.update_data(
        channel_id=channel_id
    )
    await state.set_state(UserStates.ENTER_POSTS)


@router.message(UserStates.ENTER_POSTS)
async def enter_posts(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    text = message.text
    if message.caption:
        text = message.caption

    original_text = text

    # get db data
    session = create_session(engine)
    channel = session.get(Channel, data['channel_id'])
    poster = session.get(PosterSettings, channel.channel_id)
    session.close()

    if not poster:
        await state.clear()
        return

    # get answer
    if poster.model == "gigachat":
        gigachat = Gigachat()
        await gigachat.auth(
            client_id=config.gigachat.client_id,
            client_secret=config.gigachat.client_secret
        )
        text = await gigachat.get_answer(poster.prompt.format(text))
    else:
        text = (
            config.chatgpt.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": poster.prompt.format(text)}],
            )
            .choices[0]
            .message.content
        )

    for stop_word in poster.stop_words:
        if stop_word.lower() in text:
            await bot.send_message(
                chat_id=channel.user,
                text=f"""<b>🔔 Новое сообщение от постера</b>

❌ <b>Не удалось</b> переслать сообщение из канала {channel.channel_link} в канал {poster.to_channel_link}, так как в сообщении было найдено запрещенное слово <code>{stop_word}</code>"""
            )
            await state.clear()
            return

    await asyncio.sleep(poster.latency * 60)

    # send message
    try:
        if message.caption:
            message.caption = text
        else:
            message.text = text
        await message.copy_to(
            chat_id=int(poster.to_channel_id)
        )
        await bot.send_message(
            chat_id=channel.user,
            text=f"""<b>🔔 Новое сообщение от постера</b>

✅ <b>Успешно</b> опубликовано сообщение из канала {channel.channel_link} в канал {poster.to_channel_link}

💠 Исходное сообщение: <blockquote>{original_text}</blockquote>

📝 <b>Сгенерированное сообщение:</b> <blockquote>{text}</blockquote>"""
        )
    except Exception as e:
        await bot.send_message(
            chat_id=channel.user,
            text=f"""<b>🔔 Новое сообщение от постера</b>

 ❌ <b>Не удалось</b> переслать сообщение из канала {channel.channel_link} в канал {poster.to_channel_link}
 
💠 Исходное сообщение: <blockquote>{original_text}</blockquote>

📝 <b>Сгенерированное сообщение:</b> <blockquote>{text}</blockquote>

⚠️ Если вы считаете, что ошибка на нашей стороне, отправьте нам этот текст: <code>{str(e)}</code>"""
        )
    await state.clear()


@router.message(Command("postmediagroup"), UserStates.ENTER_POSTS)
async def post_media_group(message, state: FSMContext):
    await state.set_state(UserStates.WAIT_MEDIAGROUP)

