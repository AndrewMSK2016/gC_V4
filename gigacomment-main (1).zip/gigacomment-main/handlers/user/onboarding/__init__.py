from .accounts import router as setup_accounts
from .channels import router as setup_channels
from .setup_menu import router as setup_menu
