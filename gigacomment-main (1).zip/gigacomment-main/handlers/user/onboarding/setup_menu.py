from datetime import datetime, timedelta
from random import randint

from aiogram import Router, F, Bot
from aiogram.enums import ChatAction
from aiogram.fsm.context import FSMContext
from aiogram.types import (
    CallbackQuery,
    Message,
    InlineKeyboardButton,
    KeyboardButton,
    KeyboardButtonRequestUser,
    ReplyKeyboardRemove,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder, ReplyKeyboardBuilder
from sqlalchemy.orm import create_session

from database import User, engine
from states import UserStates
from utils import Yookassa
from config import calc_final_amount

router = Router()


async def show_menu(
    state: FSMContext,
    message: Message = None,
    call: CallbackQuery = None,
):
    data = await state.get_data()
    builder = InlineKeyboardBuilder()
    builder.add(
        InlineKeyboardButton(
            text="Изменить кол-во аккаунтов", callback_data="startupchange|accounts"
        ),
        InlineKeyboardButton(
            text="Изменить кол-во каналов", callback_data="startupchange|channels"
        ),
        InlineKeyboardButton(
            text="Изменить кол-во месяцев", callback_data="startupchange|month"
        ),
        InlineKeyboardButton(
            text="Изменить пользователя для уведомлений",
            callback_data="startupchange|notification_id",
        ),
        InlineKeyboardButton(
            text="Перейти к оплате", callback_data="startupchange|continue"
        ),
    )
    builder.adjust(1)
    if message:
        await message.answer(
            text=f"""<b>🤖 Первоначальная настройка</b>
            
🔄 Аккаунтов: <b>{data['accounts']} шт.</b>
🔄 Каналов: <b>{data['channels']} шт.</b>
📆 Срок подписки: <b>{data['month']} мес.</b>
🔄 Пользователь для уведомлений: <code>{data['notification_id']}</code>
""",
            reply_markup=builder.as_markup(),
        )
    elif call:
        await call.message.edit_text(
            text=f"""<b>🤖 Первоначальная настройка</b>

🔄 Аккаунтов: <b>{data['accounts']} шт.</b>
🔄 Каналов: <b>{data['channels']} шт.</b>
📆 Срок подписки: <b>{data['month']} мес.</b>
🔄 Пользователь для уведомлений: <code>{data['notification_id']}</code>
        """,
            reply_markup=builder.as_markup(),
        )


@router.callback_query(F.data == "startup_configure")
async def show_menu_inline(call: CallbackQuery, state: FSMContext):
    await state.set_state(UserStates.STARTUP_SETUP)
    await state.set_data(
        {"accounts": 1, "channels": 0, "month": 1, "notification_id": call.from_user.id}
    )
    await show_menu(state=state, call=call)


@router.callback_query(F.data.startswith("startupchange|"))
async def request_need_data(call: CallbackQuery, state: FSMContext, bot: Bot):
    action = call.data.split("|")[1]
    cancel_builder = InlineKeyboardBuilder()
    cancel_builder.add(
        InlineKeyboardButton(text="❌ Отмена", callback_data="startup_configure")
    )
    if action == "accounts":
        await state.set_state(UserStates.ENTER_ACCOUNT_COUNT)
        await call.message.edit_text(
            text="<b>🤖 Введите количество телеграмм аккаунтов (не больше 5)</b>",
            reply_markup=cancel_builder.as_markup(),
        )
    elif action == "channels":
        await state.set_state(UserStates.ENTER_CHANNEL_COUNT)
        await call.message.edit_text(
            text="<b>🤖 Введите количество телеграмм каналов (не больше 50)</b>",
            reply_markup=cancel_builder.as_markup(),
        )
    elif action == "month":
        await state.set_state(UserStates.ENTER_MONTH_COUNT)
        await call.message.edit_text(
            text="<b>🤖 Введите количество месяцев подписки (не более 12)</b>",
            reply_markup=cancel_builder.as_markup(),
        )
    elif action == "notification_id":
        await state.set_state(UserStates.STARTUP_SETUP)
        builder = ReplyKeyboardBuilder()
        builder.add(
            KeyboardButton(
                text="Выбирать тут",
                request_user=KeyboardButtonRequestUser(request_id=randint(0, 99999999)),
            )
        )
        await call.message.edit_text(
            text="<b>🤖 Выберите контакт для отправки уведомлений</b>",
            reply_markup=cancel_builder.as_markup(),
        )
        await call.message.answer(text="ㅤ", reply_markup=builder.as_markup())
    elif action == "continue":
        await generate_invoice(call, state, bot)


@router.message(UserStates.ENTER_MONTH_COUNT)
async def apply_month_count(message: Message, state: FSMContext):
    cancel_builder = InlineKeyboardBuilder()
    cancel_builder.add(
        InlineKeyboardButton(text="❌ Отмена", callback_data="startup_configure")
    )
    if not message.text.isdigit():
        return await message.answer(
            "<b>❌ Вы ввели не число</b>", reply_markup=cancel_builder.as_markup()
        )
    count = int(message.text)
    if not (0 < count <= 12):
        return await message.answer(
            "<b>❌ Вы ввели число либо меньше нуля, либо больше 12</b>",
            reply_markup=cancel_builder.as_markup(),
        )
    await state.update_data(month=count)
    await show_menu(state=state, message=message)


@router.message(F.users_shared)
async def handle_contact(message: Message, state: FSMContext):
    user_id = message.users_shared.user_ids[0]
    await state.update_data(notification_id=user_id)
    await message.answer(text="✅ Успешно", reply_markup=ReplyKeyboardRemove())
    await show_menu(state=state, message=message)


@router.message(UserStates.ENTER_ACCOUNT_COUNT)
async def enter_account_count(message: Message, state: FSMContext):
    cancel_builder = InlineKeyboardBuilder()
    cancel_builder.add(
        InlineKeyboardButton(text="❌ Отмена", callback_data="startup_configure")
    )
    if not message.text.isdigit():
        return await message.answer(
            "<b>❌ Вы ввели не число</b>", reply_markup=cancel_builder.as_markup()
        )
    count = int(message.text)
    if not (0 < count <= 5):
        return await message.answer(
            "<b>❌ Вы ввели число либо меньше нуля, либо больше 5</b>",
            reply_markup=cancel_builder.as_markup(),
        )
    await state.update_data(accounts=count)
    await show_menu(state=state, message=message)


@router.message(UserStates.ENTER_CHANNEL_COUNT)
async def enter_channel_count(message: Message, state: FSMContext):
    cancel_builder = InlineKeyboardBuilder()
    cancel_builder.add(
        InlineKeyboardButton(text="❌ Отмена", callback_data="startup_configure")
    )
    if not message.text.isdigit():
        return await message.answer(
            "<b>❌ Вы ввели не число</b>", reply_markup=cancel_builder.as_markup()
        )
    count = int(message.text)
    if not (0 < count <= 50):
        return await message.answer(
            "<b>❌ Вы ввели число либо меньше нуля, либо больше 5</b>",
            reply_markup=cancel_builder.as_markup(),
        )
    await state.update_data(channels=count)
    await show_menu(state=state, message=message)


async def generate_invoice(call: CallbackQuery, state: FSMContext, bot: Bot):
    await bot.send_chat_action(chat_id=call.message.chat.id, action=ChatAction.TYPING)
    data = await state.get_data()
    yookassa = Yookassa()
    amount = calc_final_amount(
        accounts=data["accounts"], channels=data["channels"], month=data["month"]
    )
    # invoice_id, invoice_link = await yookassa.create_payment(amount)
    builder = InlineKeyboardBuilder()
    builder.add(
        InlineKeyboardButton(text="💸 Оплатить счет", url="https://timka.su"),
        InlineKeyboardButton(
            text="✅ Проверить оплату", callback_data=f"checkyookassa|invoice_id"
        ),
        InlineKeyboardButton(
            text="❌ Отменить оплату", callback_data="startup_configure"
        ),
    )
    builder.adjust(1)
    await call.message.edit_text(
        text=f"""<b>💸 Оплата счёта</b>
        
💰 К оплате: <b>{amount} руб.</b>
        
🤖 Остается совсем немного до момента, когда вы сможете запустить свою ферму! Оплатите счет по кнопке ниже, а затем нажмите на кнопку <b>✅ Проверить оплату</b>

🕝 В случае, если Вам необходимо подкорректировать настройки, нажмите на кнопку <b>❌ Отменить оплату</b>""",
        reply_markup=builder.as_markup(),
    )


@router.callback_query(F.data.startswith("checkyookassa"))
async def check_yookassa(call: CallbackQuery, state: FSMContext):
    invoice_id = call.data.split("|")[1]
    is_payed = True
    # yookassa = Yookassa()
    # is_payed = await yookassa.check_payment(invoice_id)
    if not is_payed:
        return await call.answer(text="❌ Вы не оплатили счет")
    state_data = await state.get_data()

    session = create_session(engine)
    user = session.get(User, call.from_user.id)
    user.is_payed = True
    user.account_count = state_data["accounts"]
    user.channels_count = state_data["channels"]
    user.month = state_data["month"]
    user.end_date = datetime.now() + timedelta(weeks=user.month * 4)
    session.commit()
    session.close()

    builder = InlineKeyboardBuilder()
    builder.add(
        InlineKeyboardButton(text="Аккаунты", callback_data="accounts"),
        InlineKeyboardButton(text="Каналы", callback_data="channels"),
    )
    builder.row(
        InlineKeyboardButton(
            text="✈️ Условия использования",
            url="https://docs.google.com/document/d/1Zf0T4gWVstpbrkfWuS19cVEuuiea1KetjsaBfJjugx0/edit?usp=sharing",
        )
    )
    await call.message.edit_text(
        text="✅ Оплата прошла успешно. Вам открыт доступ к функционалу бота. Используйте клавиатуру ниже для управления",
        reply_markup=builder.as_markup(),
    )
    await call.answer(text="✅ Счет оплачен")
