from aiogram import Router, F
from aiogram.types import CallbackQuery, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sqlalchemy.orm import create_session

from database import engine, PosterSettings, Channel, CommenterSettings, Account, User

router = Router()


@router.callback_query(F.data == "cancel_subscription")
async def request_cancel_confirm(call: CallbackQuery):
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="❌ Не отменять", callback_data="menu"),
        InlineKeyboardButton(text="😔 Отменить", callback_data="confirmcancelsub"),
    )
    await call.message.edit_text(
        text=f"""<b>😔 Вы уверены?</b>
        
Нажимая кнопку <b>“Удалить подписку”</b> вы подтверждаете, что все <b>ранее введенные данные и настройки будут стерты, денежные средства не возвращаются</b>""",
        reply_markup=builder.as_markup(),
    )


@router.callback_query(F.data == "confirmcancelsub")
async def cancel_subscription(call: CallbackQuery):
    session = create_session(engine)
    channels = session.query(Channel).filter_by(user=call.from_user.id).all()
    user = session.get(User, call.from_user.id)
    for channel in channels:
        session.query(PosterSettings).filter_by(channel_id=channel.id).delete()
        session.query(CommenterSettings).filter_by(channel_id=channel.id).delete()
        session.delete(channel)
        session.commit()
    session.commit()
    session.query(Account).filter_by(user=call.from_user.id).delete()
    user.is_payed = False
    user.end_date = None
    session.commit()
    session.close()
    await call.message.edit_text(
        text=f"""<b>😢 Вы отменили подписку :(</b>
        
👤 Если захотите вернуться - пропишите /start! Мы будем рады!"""
    )
