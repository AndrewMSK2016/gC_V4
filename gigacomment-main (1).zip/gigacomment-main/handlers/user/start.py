from collections import UserList
from datetime import timedelta, datetime

from aiogram import Router, F
from aiogram.filters.command import Command
from aiogram.types import CallbackQuery, Message, InlineKeyboardButton
from sqlalchemy.orm import create_session
from aiogram.utils.keyboard import InlineKeyboardBuilder

from database import engine, User, Account, Channel, CommenterSettings, PosterSettings

router = Router()


@router.message(Command("start"))
async def start_command(message: Message):
    session = create_session(engine)
    user = session.get(User, message.from_user.id)
    if not user:
        user = User(id=message.from_user.id, notification_id=message.from_user.id)
        session.add(user)
        session.commit()
    builder = InlineKeyboardBuilder()
    if not user.is_payed:
        builder.add(
            InlineKeyboardButton(text="🚀 Поехали!", callback_data="startup_configure")
        )
        return await message.answer(
            text="<b>Добро пожаловать! Давайте начнем настройку!</b>",
            reply_markup=builder.as_markup(),
        )

    current_accounts = session.query(Account).filter_by(user=user.id).count()
    current_channels = session.query(Channel).filter_by(user=user.id).count()

    comments_count = 0
    posted_count = 0

    channels = session.query(Channel).filter_by(user=user.id).all()

    for channel in channels:
        if channel.mode == "comments":
            commenter = (
                session.query(CommenterSettings)
                .filter_by(channel_id=channel.id)
                .first()
            )
            if commenter:
                comments_count += commenter.comments_count
        elif channel.mode == "posting":
            poster_settings = (
                session.query(PosterSettings).filter_by(channel_id=channel.id).first()
            )
            if poster_settings:
                posted_count += poster_settings.posted_count

    if not user.end_date:
        user.end_date = datetime.now() + timedelta(weeks=4 * user.month)
        session.commit()

    session.close()

    builder.add(
        InlineKeyboardButton(text="Аккаунты", callback_data="accounts"),
        InlineKeyboardButton(text="Каналы", callback_data="channels"),
    )
    builder.row(
        InlineKeyboardButton(
            text="✈️ Условия использования",
            url="https://docs.google.com/document/d/1Zf0T4gWVstpbrkfWuS19cVEuuiea1KetjsaBfJjugx0/edit?usp=sharing",
        )
    )
    builder.row(
        InlineKeyboardButton(
            text="❌ Отменить подписку", callback_data="cancel_subscription"
        ),
    )
    await message.answer(
        text=f"""Продолжим. Вы в главном меню.

<b>📝 Статистика</b>
📆 Дата окончания подписки: <code>{user.end_date.strftime('%m.%d.%Y, %H:%M:%S')}</code>
🤖 Аккаунты: <b>{current_accounts}/{user.account_count}</b>
📧 Каналы: <b>{current_channels}/{user.channels_count}</b>

💠 Оставлено комментариев: <b>{comments_count}</b>
📇 Оставлено постов: <b>{posted_count}</b>
    """,
        reply_markup=builder.as_markup(),
    )


@router.callback_query(F.data == "menu")
async def menu_inline(call: CallbackQuery):
    session = create_session(engine)
    user = session.get(User, call.from_user.id)
    current_accounts = session.query(Account).filter_by(user=user.id).count()
    current_channels = session.query(Channel).filter_by(user=user.id).count()

    comments_count = 0
    posted_count = 0

    channels = session.query(Channel).filter_by(user=user.id).all()

    for channel in channels:
        if channel.mode == "comments":
            commenter = (
                session.query(CommenterSettings)
                .filter_by(channel_id=channel.id)
                .first()
            )
            if commenter:
                comments_count += commenter.comments_count
        elif channel.mode == "posting":
            poster_settings = (
                session.query(PosterSettings).filter_by(channel_id=channel.id).first()
            )
            if poster_settings:
                posted_count += poster_settings.posted_count

    if not user.end_date:
        user.end_date = datetime.now() + timedelta(weeks=4 * user.month)
        session.commit()

    session.close()
    builder = InlineKeyboardBuilder()

    builder.add(
        InlineKeyboardButton(text="Аккаунты", callback_data="accounts"),
        InlineKeyboardButton(text="Каналы", callback_data="channels"),
    )
    builder.row(
        InlineKeyboardButton(
            text="✈️ Условия использования",
            url="https://docs.google.com/document/d/1Zf0T4gWVstpbrkfWuS19cVEuuiea1KetjsaBfJjugx0/edit?usp=sharing",
        )
    )
    builder.row(
        InlineKeyboardButton(
            text="❌ Отменить подписку", callback_data="cancel_subscription"
        ),
    )
    await call.message.edit_text(
        text=f"""Продолжим. Вы в главном меню.
        
<b>📝 Статистика</b>
📆 Дата окончания подписки: <code>{user.end_date.strftime('%m.%d.%Y, %H:%M:%S')}</code>
🤖 Аккаунты: <b>{current_accounts}/{user.account_count}</b>
📧 Каналы: <b>{current_channels}/{user.channels_count}</b>

💠 Оставлено комментариев: <b>{comments_count}</b>
📇 Оставлено постов: <b>{posted_count}</b>
""",
        reply_markup=builder.as_markup(),
    )
