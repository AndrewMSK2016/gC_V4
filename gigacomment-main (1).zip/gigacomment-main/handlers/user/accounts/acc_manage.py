from os import remove

from aiogram import F, Router, Bot
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sqlalchemy.orm import create_session

from database import (
    engine,
    User,
    Account,
    UserAgent,
    Channel,
    PosterSettings,
    CommenterSettings,
)
from states import UserStates
from userbot import check_account as chacc
from utils.tg_utils import TelegramTools
from .add_account import list_accounts


router = Router()


def force_delete_account(account_id: int):
    session = create_session(engine)
    account = session.get(Account, account_id)
    channels = session.query(Channel).filter_by(account=account.id).all()
    if channels:
        for channel in channels:
            poster = (
                session.query(PosterSettings).filter_by(channel_id=channel.id).first()
            )
            if poster:
                session.delete(poster)
                session.commit()
            commenter = (
                session.query(CommenterSettings)
                .filter_by(channel_id=channel.id)
                .first()
            )
            if commenter:
                session.delete(commenter)
                session.commit()
            session.delete(channel)
            session.commit()
    session.delete(account)
    session.commit()
    session.close()


@router.callback_query(F.data.startswith("infoaccount_"))
async def show_acc_info(call: CallbackQuery):
    await call.answer(text="⏳ Загружаю информацию, это не займет больше 5 секунд")
    acc_id = int(call.data.split("_")[1])
    session = create_session(engine)
    account = session.get(Account, acc_id)
    try:
        tgtools = TelegramTools(account.file_id)
        profile = await tgtools.get_account_info()
        if not profile:
            raise Exception("profile is not valid")
    except Exception as e:
        print(e)
        force_delete_account(acc_id)
        return await call.answer(
            text="❌ Увы, но данный аккаунт невалиден. Он вместе с каналами был удален",
            show_alert=True,
        )

    session.close()

    builder = InlineKeyboardBuilder()

    builder.add(
        InlineKeyboardButton(
            text="📝 Изменить имя", callback_data=f"editaccountinfo_name_{acc_id}"
        ),
        InlineKeyboardButton(
            text="📝 Изменить фамилию",
            callback_data=f"editaccountinfo_surname_{acc_id}",
        ),
        InlineKeyboardButton(
            text="📝 Изменить био", callback_data=f"editaccountinfo_bio_{acc_id}"
        ),
        InlineKeyboardButton(
            text="👤 Изменить юзернейм",
            callback_data=f"editaccountinfo_username_{acc_id}",
        ),
        InlineKeyboardButton(
            text="🖼️ Изменить аватарку", callback_data=f"editaccountinfo_avatar_{acc_id}"
        ),
        InlineKeyboardButton(text="🔎 Проверить", callback_data=f"chkacc_{acc_id}"),
        InlineKeyboardButton(text="🗑️ Удалить", callback_data=f"delacc_{acc_id}"),
        InlineKeyboardButton(text="🏠 Обратно", callback_data="accounts"),
    )
    builder.adjust(2)
    await call.message.edit_text(
        text=f"""<b>🤖 Аккаунт #{acc_id}</b>

🆔 Внутренний ID: <code>{account.file_id}</code>

<b>👤 Информация о профиле</b>
🆔 ID: <code>{profile.id}</code>
📝 Имя: <b>{profile.first_name} {profile.last_name if profile.last_name else ""}</b>
👤 Юзернейм: {f"@{profile.username}" if profile.username else "<i>не установлен</i>"}
☎️ Номер телефона: <code>+{profile.phone_number}</code>

📝 Био: <code>{profile.bio}</code>

<b>📈 Используйте клавиатуру ниже для настройки</b>""",
        reply_markup=builder.as_markup(),
    )


@router.callback_query(F.data.startswith("editaccountinfo"))
async def request_account_data(call: CallbackQuery, state: FSMContext):
    action, account_id = call.data.split("_")[1], int(call.data.split("_")[2])
    tgtools = TelegramTools(TelegramTools.get_file_id(account_id))
    await state.update_data(tools=tgtools, action=action, account_id=account_id)
    await state.set_state(UserStates.ENTER_NEW_ACCOUNT_DATA)
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text="❌ Отмена", callback_data=f"infoaccount_{account_id}"
        )
    )
    await call.message.edit_text(
        text="📝 Введите новый параметр аккаунта", reply_markup=builder.as_markup()
    )


@router.message(UserStates.ENTER_NEW_ACCOUNT_DATA)
async def apply_account_data(message: Message, state: FSMContext, bot: Bot):
    msg = await message.answer(text="<i>⌛ Подождите пару секунд, пожалуйста</i>")

    state_data = await state.get_data()
    tgtools: TelegramTools = state_data["tools"]
    action: str = state_data["action"]
    acc_id = state_data["account_id"]
    session = create_session(engine)
    account = session.get(Account, acc_id)
    session.close()
    is_success = False

    if action == "name":
        is_success = await tgtools.change_name(message.text)
    elif action == "bio":
        is_success = await tgtools.change_bio(message.text)
    elif action == "surname":
        is_success = await tgtools.change_surname(message.text)
    elif action == "username":
        is_success = await tgtools.change_username(message.text)
    elif action == "avatar":
        if message.video:
            video_name = await bot.download(message.video)
            is_success = await tgtools.change_avatar(video_name, "video")
        elif message.photo:
            photo_name = await bot.download(message.photo[-1])
            is_success = await tgtools.change_avatar(photo_name, "photo")

    await msg.delete()
    if is_success:
        await message.answer(text="✅ Успешно")
    else:
        await message.answer(
            text="❌ Произошла ошибка, проверьте вводимые данные и попробуйте еще раз"
        )

    msg2 = await message.answer(
        text="<i>⏳ Загружаю информацию, это не займет много времени</i>"
    )
    try:
        tgtools = TelegramTools(account.file_id)
        profile = await tgtools.get_account_info()
        if not profile:
            raise Exception("profile is not valid")
    except:
        force_delete_account(acc_id)
        return await message.answer(
            text="❌ Увы, но данный аккаунт невалиден. Он вместе с каналами был удален",
            show_alert=True,
        )

    builder = InlineKeyboardBuilder()
    builder.add(
        InlineKeyboardButton(
            text="📝 Изменить имя", callback_data=f"editaccountinfo_name_{acc_id}"
        ),
        InlineKeyboardButton(
            text="📝 Изменить фамилию",
            callback_data=f"editaccountinfo_surname_{acc_id}",
        ),
        InlineKeyboardButton(
            text="📝 Изменить био", callback_data=f"editaccountinfo_bio_{acc_id}"
        ),
        InlineKeyboardButton(
            text="👤 Изменить юзернейм",
            callback_data=f"editaccountinfo_username_{acc_id}",
        ),
        InlineKeyboardButton(
            text="🖼️ Изменить аватарку", callback_data=f"editaccountinfo_avatar_{acc_id}"
        ),
        InlineKeyboardButton(text="🔎 Проверить", callback_data=f"chkacc_{acc_id}"),
        InlineKeyboardButton(text="🗑️ Удалить", callback_data=f"delacc_{acc_id}"),
        InlineKeyboardButton(text="🏠 Обратно", callback_data="accounts"),
    )
    builder.adjust(2)
    await msg2.delete()
    await message.answer(
        text=f"""<b>🤖 Аккаунт #{acc_id}</b>

🆔 Внутренний ID: <code>{account.file_id}</code>

<b>👤 Информация о профиле</b>
🆔 ID: <code>{profile.id}</code>
📝 Имя: <b>{profile.first_name} {profile.last_name if profile.last_name else ""}</b>
👤 Юзернейм: {f"@{profile.username}" if profile.username else "<i>не установлен</i>"}
☎️ Номер телефона: <code>+{profile.phone_number}</code>

📝 Био: <code>{profile.bio}</code>

<b>📈 Используйте клавиатуру ниже для настройки</b>""",
        reply_markup=builder.as_markup(),
    )


@router.callback_query(F.data.startswith("delacc_"))
async def request_confirm_delete_accs(call: CallbackQuery):
    acc_id = int(call.data.split("_")[1])
    builder = InlineKeyboardBuilder()
    builder.add(
        InlineKeyboardButton(text="✅ Да", callback_data=f"deleteacc_{acc_id}"),
        InlineKeyboardButton(text="❌ Нет", callback_data=f"infoaccount_{acc_id}"),
    )
    await call.message.edit_text(
        text="🤔 Вы уверены, что хотите удалить аккаунт?",
        reply_markup=builder.as_markup(),
    )


@router.callback_query(F.data.startswith("deleteacc_"))
async def delete_account(call: CallbackQuery):
    acc_id = int(call.data.split("_")[1])
    session = create_session(engine)
    account = session.get(Account, acc_id)
    session.delete(account)
    try:
        session.commit()
    except:
        await call.answer(
            text="❌ Аккаунт не может быть удален, поскольку он используется в каналах.",
            show_alert=True,
        )
        session.close()
        return
    session.close()

    await call.answer(text="🗑️ Аккаунт удален", show_alert=True)
    await list_accounts(call)


@router.callback_query(F.data.startswith("chkacc_"))
async def check_account(call: CallbackQuery):
    acc_id = int(call.data.split("_")[1])
    session = create_session(engine)
    account = session.get(Account, acc_id)
    ua: UserAgent = session.get(UserAgent, account.useragent)

    is_valid = await chacc(account.file_id, ua)
    remove(f"accounts/sessions/{account.file_id}-2.session")
    if is_valid:
        session.close()
        return await call.answer("✅ Аккаунт валид!", show_alert=True)
    await call.answer(text="❌ Аккаунт невалидный, он выключен", show_alert=True)
    force_delete_account(acc_id)
    await list_accounts(call)
