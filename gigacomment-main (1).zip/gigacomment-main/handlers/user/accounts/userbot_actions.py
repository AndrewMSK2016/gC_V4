from typing import BinaryIO

from aiogram import Router, F, Bot
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder

from states import UserStates
from utils.tg_utils import TelegramTools

router = Router()


@router.callback_query(F.data.startswith("answerpm"))
async def request_answer_text(call: CallbackQuery, state: FSMContext):
    account_id, user_id, forward_from = (
        int(call.data.split("|")[1]),
        int(call.data.split("|")[2]),
        int(call.data.split("|")[3]),
    )

    await state.set_state(UserStates.ENTER_USERBOT_REPLY)
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="❌ Отмена", callback_data="cancelpmreply"))
    msg = await call.message.answer(
        text="📧 Введите ответ собеседнику Вашего юзербота",
        reply_markup=builder.as_markup(),
    )
    await state.update_data(
        account_id=account_id,
        user_id=user_id,
        msg_id=msg.message_id,
        forward_from=forward_from,
    )


@router.callback_query(F.data == "cancelpmreply")
async def cancel_reply(call: CallbackQuery, state: FSMContext):
    await state.clear()
    await call.message.delete()


@router.message(UserStates.ENTER_USERBOT_REPLY)
async def send_msg_to_user(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    await state.clear()
    msg = await message.forward(chat_id=data["forward_from"])

    msg1 = await message.answer(text="<i>⏳ Подождите...</i>")
    binary = BinaryIO()
    if message.video:
        binary = await bot.download(message.video.file_id)
        binary.name = message.video.file_name
    elif message.photo:
        binary = await bot.download(message.photo[-1].file_id)
    elif message.document:
        binary = await bot.download(message.document.file_id)
        binary.name = message.document.file_name
    elif message.voice:
        binary = await bot.download(message.voice.file_id)
        binary.name = message.voice.file_id
    elif message.video_note:
        binary = await bot.download(message.video_note.file_id)
        binary.name = message.video_note.file_id
    elif message.audio:
        binary = await bot.download(message.audio.file_id)
        binary.name = message.audio.file_name

    tools = TelegramTools(TelegramTools.get_file_id(data["account_id"]))
    is_success = await tools.send_message(data["user_id"], msg, binary=binary)
    await bot.delete_message(chat_id=message.chat.id, message_id=data["msg_id"])
    await msg1.delete()

    if not is_success:
        await message.answer(text="❌ Ошибка при отправке сообщения!")
    else:
        await message.answer(text="✅ Успешно!")
