import os
import platform
from logging import info, error
from random import choice
from shutil import rmtree
from threading import Thread
from zipfile import ZipFile
from os import listdir, remove, system

from aiogram import Router, F, Bot
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sqlalchemy.orm import create_session

from config import config
from database import engine, Account, User, UserAgent, AccountProxy
from states import UserStates
from utils import tdata_to_pyrogram

router = Router()


@router.callback_query(F.data == "accounts")
async def list_accounts(call: CallbackQuery):
    session = create_session(engine)
    accounts = session.query(Account).filter_by(user=call.from_user.id).all()
    user = session.get(User, call.from_user.id)
    session.close()
    builder = InlineKeyboardBuilder()
    if not accounts:
        builder.row(InlineKeyboardButton(text="➕ Добавить", callback_data="load_accs"))
        builder.row(
            InlineKeyboardButton(text="🏠 В меню", callback_data="menu"),
        )
        builder.adjust(1)
        return await call.message.edit_text(
            text="❌ На данный момент аккаунтов нет.", reply_markup=builder.as_markup()
        )
    if user.account_count != len(accounts):
        builder.row(InlineKeyboardButton(text="➕ Добавить", callback_data="load_accs"))
    for account in accounts:
        if account.mode == "active":
            builder.row(
                InlineKeyboardButton(
                    text=account.file_id[0:8], callback_data=f"infoaccount_{account.id}"
                )
            )
    builder.row(
        InlineKeyboardButton(text="🏠 В меню", callback_data="menu"),
    )
    await call.message.edit_text(
        text=f"👤 Управление аккаунтами Telegram.", reply_markup=builder.as_markup()
    )


# load account
@router.callback_query(F.data == "load_accs")
async def request_zipaccs(call: CallbackQuery, state: FSMContext):
    builder = InlineKeyboardBuilder()
    builder.add(InlineKeyboardButton(text="❌ Отмена", callback_data="accounts"))
    await call.message.edit_text(
        text="""📂 Загрузите мне в диалог zip-архив с аккаунтами Telegram в формате tdata (до 25мб)
        
<b>⚠️ Воздержитесь от использования краденых или свежесозданных аккаунтов. Рекомендуется покупать автоматически зарегистрированные аккаунты с датой регистрации не менее 30 дней</b>""",
        reply_markup=builder.as_markup(),
    )
    await state.set_state(UserStates.ENTER_ACCOUNTS_ZIP)


@router.message(UserStates.ENTER_ACCOUNTS_ZIP)
async def process_and_check(message: Message, state: FSMContext, bot: Bot):
    cancel_builder = InlineKeyboardBuilder()
    cancel_builder.add(InlineKeyboardButton(text="❌ Отмена", callback_data="accounts"))
    msg = await message.answer(text=f"⏳ Начинаю обработку. Ожидайте.")
    if not message.document:
        await msg.delete()
        return await message.answer(
            text="❌ Вы не загрузили архив. Пожалуйста, попробуйте еще раз",
            reply_markup=cancel_builder.as_markup(),
        )

    # download
    try:
        file = await message.bot.get_file(message.document.file_id)
        await message.bot.download_file(
            file.file_path, f"accounts/tdata-{message.from_user.id}.zip"
        )
    except Exception as e:
        print(e)
        await msg.delete()
        return await message.answer(
            text="❌ Ошибка при загрузке. Попробуйте еще раз",
            reply_markup=cancel_builder.as_markup(),
        )

    # unpack zip
    try:
        with ZipFile(f"accounts/tdata-{message.from_user.id}.zip", "r") as zipfile:
            zipfile.extractall(f"accounts/tdata-{message.from_user.id}")
    except:
        await msg.delete()
        return await message.answer(
            text="❌ Ошибка при распаковке архива. Попробуйте еще раз",
            reply_markup=cancel_builder.as_markup(),
        )

    try:
        remove(f"accounts/tdata-{message.from_user.id}.zip")
        print("removed zip")
    except:
        ...

    session = create_session(bind=engine)
    before_cnt = session.query(Account).filter_by(user=message.from_user.id).count()
    user = session.get(User, message.from_user.id)
    if user.account_count == before_cnt:
        await msg.delete()
        return await message.answer(
            text=f"❌ Вы не можете загружать аккаунты, пока не удалить другие. Ваш лимит аккаунтов: <b>{cnt} шт.</b>",
            reply_markup=cancel_builder.as_markup(),
        )
    curr_cnt = 0
    account_list = listdir(f"accounts/tdata-{message.from_user.id}")
    try:
        account_list.remove("__MACOSX")
    except:
        ...
    for folder_name in account_list:
        try:
            if user.account_count <= before_cnt:
                await state.clear()
                await msg.delete()
                session.close()
                return await message.answer(
                    text=f"❌ Вы не можете загружать аккаунты, пока не удалить другие. Ваш лимит аккаунтов: <b>{curr_cnt} шт.</b>"
                )
            proxy = choice(config.proxies)
            proxy = AccountProxy(
                host=proxy.host,
                port=proxy.port,
                login=proxy.login,
                password=proxy.password,
                proxy_type=proxy.proxy_type,
            )
            account_id, telegram_id, useragent = await tdata_to_pyrogram(
                f"accounts/tdata-{message.from_user.id}/{folder_name}", proxy
            )

            if account_id == 0:
                await message.answer(
                    text=f"❌ Аккаунт {folder_name} невалидный. Продолжаю дальше."
                )
                continue

            user = session.get(User, message.from_user.id)
            ua = UserAgent(
                device_model=useragent.device_model,
                system_version=useragent.system_version,
                app_version=useragent.app_version,
                lang_code=useragent.lang_code,
            )
            session.add(ua)
            session.add(proxy)
            session.commit()
            account = Account(
                user=message.from_user.id,
                file_id=account_id,
                mode="active",
                useragent=ua.id,
                telegram_id=telegram_id,
            )
            session.add(account)
            session.commit()
            before_cnt += 1
            curr_cnt += 1
            if os.name == "nt":
                thread = Thread(
                    target=lambda: system(
                        f".\\venv\Scripts\python userbot/core.py {account.file_id.replace('.session', '')} {useragent.id} {proxy.id if proxy else -1}"
                    )
                )
            else:
                thread = Thread(
                    target=lambda: system(
                        f"venv/bin/python3 userbot/core.py {account.file_id.replace('.session', '')} {useragent.id} {proxy.id if proxy else -1}"
                    )
                )
            thread.start()
            info(f"Loaded account {account_id}")
        except:
            await message.answer(
                text=f"❌ Ошибка при обработке аккаунта {folder_name}. Продолжаю дальше."
            )

    rmtree(f"accounts/tdata-{message.from_user.id}/")
    print("final step")
    session.close()
    await state.clear()
    builder = InlineKeyboardBuilder()
    builder.add(InlineKeyboardButton(text="🏠 К аккаунтам", callback_data="accounts"))
    await msg.delete()
    if curr_cnt != 0:
        await message.answer(
            text=f"✅ Успешно обработано и добавлено {curr_cnt} аккаунтов",
            reply_markup=builder.as_markup(),
        )
    else:
        await message.answer(
            text=f"❌ Не удалось обработать ни одного аккаунта",
            reply_markup=builder.as_markup(),
        )
