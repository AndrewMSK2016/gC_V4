import shutil
from os import remove

from aiogram import Router, F
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sqlalchemy.orm import create_session

from database import Channel, engine, Account, UserAgent
from database.models.user import User
from states import UserStates
from userbot import join_channel


router = Router()


@router.callback_query(F.data == "channels")
async def list_channels(call: CallbackQuery):
    session = create_session(engine)
    channels = session.query(Channel).filter_by(user=call.from_user.id).all()
    ind = 0
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="➕ Добавить", callback_data="addchl"))
    for channel in channels:
        try:
            builder.row(
                InlineKeyboardButton(
                    text=f"#{channel.id} - {channel.channel_link}",
                    callback_data=f"chinf_{channel.id}",
                )
            )
            ind += 1
        except:
            break
    builder.row(
        InlineKeyboardButton(text="1", callback_data="pass"),
        InlineKeyboardButton(text="➡️", callback_data=f"chpage_{ind + 1}"),
    )
    builder.row(InlineKeyboardButton(text=f"🏠 Обратно", callback_data="menu"))
    await call.message.edit_text(
        text=f"📂 Выберите канал для редактирования", reply_markup=builder.as_markup()
    )


@router.callback_query(F.data == "addchl")
async def select_account(call: CallbackQuery):
    session = create_session(engine)
    accounts = session.query(Account).filter_by(user=call.from_user.id).all()
    session.close()
    builder = InlineKeyboardBuilder()
    for account in accounts:
        builder.row(
            InlineKeyboardButton(
                text=account.file_id[0:8], callback_data=f"acacc_{account.id}"
            )
        )
    builder.add(InlineKeyboardButton(text="❌ Отмена", callback_data="cancel"))
    await call.message.edit_text(
        text="Выберите аккаунт, который будет совершать действия в каналах",
        reply_markup=builder.as_markup(),
    )


# add new channel
@router.callback_query(F.data.startswith("acacc_"))
async def request_links(call: CallbackQuery, state: FSMContext):
    account_id = int(call.data.split("_")[1])
    await state.update_data(account_id=account_id)
    builder = InlineKeyboardBuilder()
    builder.add(InlineKeyboardButton(text="❌ Отмена", callback_data="cancel"))
    await call.message.edit_text(
        text=f"Введите ссылки на каналы. Каждый с новой строки.",
        reply_markup=builder.as_markup(),
    )
    await state.set_state(UserStates.ENTER_CHANNELS)


@router.message(UserStates.ENTER_CHANNELS)
async def process_channels(message: Message, state: FSMContext):
    data = await state.get_data()
    links = message.text.split("\n")
    msg = await message.answer(text=f"🚀 Начал вступать в каналы. Ожидайте.")
    builder = InlineKeyboardBuilder()

    session = create_session(engine)
    account = session.get(Account, data["account_id"])
    cnt = session.query(Channel).filter_by(user=message.from_user.id).count()
    user = session.get(User, message.from_user.id)

    if not account:
        await msg.delete()
        await state.clear()

        builder.row(
            InlineKeyboardButton(text="🚀 К аккаунтам", callback_data="accounts")
        )

        await message.answer(
            text="❌ У вас нет аккаунтов! Пожалуйста, загрузите их",
            reply_markup=builder.as_markup(),
        )
        return

    ind = 0
    curr_cnt = 0
    for link in links:
        if user.channels_count <= cnt:
            await msg.delete()
            await state.clear()

            builder.row(
                InlineKeyboardButton(text="📂 К каналам", callback_data="channels")
            )

            await message.answer(
                text="🔔 Обработка завершена досрочно, поскольку Ваш лимит на кол-во каналов исчерпан",
                reply_markup=builder.as_markup(),
            )
            return

        ua = session.get(UserAgent, account.useragent)
        status, code, chat_id, linked_chat = await join_channel(
            account_id=account.file_id, chat_link=link, ua=ua
        )
        remove(f"accounts/sessions/{account.file_id}-2.session")
        if not status:
            await message.answer(
                f"❌ Не удалось зайти в канал. Ошибка: <code>{code}</code>\nПродолжаем."
            )
            continue
        curr_cnt += 1
        cnt += 1

        if not linked_chat:
            await message.answer(
                text=f"⚠️ В канале {link} не поддерживается комментирование постов!"
            )

        channel = Channel(
            user=user.id,
            account=account.id,
            channel_link=link,
            channel_id=chat_id,
            comments_open=linked_chat,
            mode="posting" if not linked_chat else "comments",
        )
        session.add(channel)
        session.commit()
    session.close()
    await msg.delete()
    await state.clear()
    builder.row(InlineKeyboardButton(text="📂 К каналам", callback_data="channels"))

    if curr_cnt != 0:
        await message.answer(
            text=f"🔔 Обработка завершена. Обработано {curr_cnt} каналов",
            reply_markup=builder.as_markup(),
        )
    else:
        await message.answer(
            text=f"❌ Не удалось зайти ни в один канал. Попробуйте еще раз.",
            reply_markup=builder.as_markup(),
        )
