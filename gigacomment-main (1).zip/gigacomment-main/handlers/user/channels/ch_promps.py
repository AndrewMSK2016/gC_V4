from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sqlalchemy.orm import create_session

from config import config
from database import engine, Channel, CommenterSettings, PosterSettings
from states import UserStates
from userbot.gigachat import Gigachat

router = Router()


@router.callback_query(F.data.startswith("chprompts_"))
async def manage_promps(call: CallbackQuery, state: FSMContext):
    await state.clear()

    channel_id = int(call.data.split("_")[1])
    session = create_session(engine)
    channel = session.get(Channel, channel_id)
    commenter = (
        session.query(CommenterSettings).filter_by(channel_id=channel.id).first()
    )
    if not commenter:
        commenter = CommenterSettings(channel_id=channel_id)
        session.add(commenter)
        session.commit()
    poster = session.query(PosterSettings).filter_by(channel_id=channel_id).first()
    if not poster:
        poster = PosterSettings(channel_id=channel_id)
        session.add(poster)
        session.commit()
    session.close()

    builder = InlineKeyboardBuilder()
    builder.add(
        InlineKeyboardButton(
            text="Комментарий под постом",
            callback_data=f"setprompt_{channel_id}_postcomment",
        ),
        InlineKeyboardButton(
            text="Ответ на комментарий",
            callback_data=f"setprompt_{channel_id}_postreply",
        ),
        InlineKeyboardButton(
            text="Перефразирование поста",
            callback_data=f"setprompt_{channel_id}_posterresend",
        ),
        InlineKeyboardButton(text="🏠 Обратно", callback_data=f"chinf_{channel_id}"),
    )
    builder.adjust(1)
    await call.message.edit_text(
        text=f"""<b>💡 Дом ваших промптов</b>
        
<b>📂 Нейрокомментинг</b>
👤 Комментарий под постом: <code>{commenter.comment_prompt}</code>
👤 Ответ на коммантарий: <code>{commenter.answer_prompt}</code>

<b>🔗 Нейропостинг</b>
🔔 Перефразирование поста: <code>{poster.prompt}</code>""",
        reply_markup=builder.as_markup(),
    )


@router.callback_query(F.data.startswith("setprompt_"))
async def request_new_prompt(call: CallbackQuery, state: FSMContext):
    channel_id = int(call.data.split("_")[1])
    action = call.data.split("_")[2]
    await state.set_state(UserStates.ENTER_PROMPT)
    await state.update_data(action=action, channel_id=channel_id)
    builder = InlineKeyboardBuilder()
    builder.add(
        InlineKeyboardButton(text="❌ Отмена", callback_data=f"chprompts_{channel_id}")
    )
    await call.message.edit_text(
        text="""<b>📂 Введите новое значение параметра</b>
        
💡 Для подстановки значения текста сообщения в промпт, используйте оператор <code>{}</code>""",
        reply_markup=builder.as_markup(),
    )


@router.message(UserStates.ENTER_PROMPT)
async def apply_prompt(message: Message, state: FSMContext):
    data = await state.get_data()

    actions = {
        "postcomment": "Комментирование под постом",
        "postreply": "Ответ на пост",
        "posterresend": "Пересылка постингом",
    }

    builder = InlineKeyboardBuilder()
    builder.add(
        InlineKeyboardButton(
            text="🧳 Проверить на стандартной фразе", callback_data="pr|check"
        ),
        InlineKeyboardButton(text="✅ Поставить", callback_data="pr|apply"),
        InlineKeyboardButton(
            text="❌ Отмена", callback_data=f"chprompts_{data['channel_id']}"
        ),
    )
    builder.adjust(1)

    await message.answer(
        text=f"""<b>📝 Проверьте ваш промпт</b>
        
💠 Вы устанавливаете промпт <code>{message.text}</code> для действия <b>{actions[data['action']]}</b>""",
        reply_markup=builder.as_markup(),
    )
    await state.update_data(prompt=message.text)


async def get_answer(action: str, state_data: dict):
    phrase = "Не стоит нести людям добро, если они этого не просят. Вам это дорого обойдется. Лучшее, что можно сделать — положить добро на видное место и тихонько отойти. Кому надо — тот сам возьмет."

    session = create_session(engine)
    commenter = (
        session.query(CommenterSettings)
        .filter_by(channel_id=state_data["channel_id"])
        .first()
    )
    poster = (
        session.query(PosterSettings)
        .filter_by(channel_id=state_data["channel_id"])
        .first()
    )
    if action in ["postcomment", "postreply"]:
        if commenter.model == "chatgpt":
            return config.chatgpt.chat.completions.create(
                model="gpt3.5-turbo", messages=[{"type": "user", "content": phrase}]
            )
        else:
            gigachat = Gigachat()
            await gigachat.auth(
                client_id=config.gigachat.client_id,
                client_secret=config.gigachat.client_secret,
            )
            return await gigachat.get_answer(state_data["prompt"].format(phrase))
    else:
        if poster.model == "chatgpt":
            return config.chatgpt.chat.completions.create(
                model="gpt3.5-turbo", messages=[{"type": "user", "content": phrase}]
            )
        else:
            gigachat = Gigachat()
            await gigachat.auth(
                client_id=config.gigachat.client_id,
                client_secret=config.gigachat.client_secret,
            )
            return await gigachat.get_answer(state_data["prompt"].format(phrase))


@router.callback_query(F.data.startswith("pr|"))
async def prompt_actions(call: CallbackQuery, state: FSMContext):
    action = call.data.split("|")[1]
    data = await state.get_data()
    session = create_session(engine)
    commenter = (
        session.query(CommenterSettings)
        .filter_by(channel_id=data["channel_id"])
        .first()
    )
    poster = (
        session.query(PosterSettings).filter_by(channel_id=data["channel_id"]).first()
    )

    if action == "check":
        await call.answer(text="💠 Отсылаю запрос, ожидайте!", show_alert=True)
        answer = await get_answer(data["action"], data)
        await call.message.edit_text(
            text=call.message.html_text
            + f"\n\n<b>💠 Результат тестирования промпта:</b> <blockquote>{answer}</blockquote>",
            reply_markup=call.message.reply_markup,
        )
    elif action == "apply":
        apply_action = data["action"]
        if apply_action == "postcomment":
            commenter.comment_prompt = data["prompt"]
            session.commit()
        elif apply_action == "postreply":
            commenter.answer_prompt = data["prompt"]
            session.commit()
        elif apply_action == "posterresend":
            poster.prompt = data["prompt"]
            session.commit()

        session.close()

        channel_id = poster.channel_id
        builder = InlineKeyboardBuilder()
        builder.add(
            InlineKeyboardButton(
                text="Комментарий под постом",
                callback_data=f"setprompt_{channel_id}_postcomment",
            ),
            InlineKeyboardButton(
                text="Ответ на комментарий",
                callback_data=f"setprompt_{channel_id}_postreply",
            ),
            InlineKeyboardButton(
                text="Перефразирование поста",
                callback_data=f"setprompt_{channel_id}_posterresend",
            ),
            InlineKeyboardButton(
                text="🏠 Обратно", callback_data=f"chinf_{channel_id}"
            ),
        )
        builder.adjust(1)
        await call.message.edit_text(
            text=f"""<b>💡 Дом ваших промптов</b>

<b>📂 Нейрокомментинг</b>
👤 Комментарий под постом: <code>{commenter.comment_prompt}</code>
👤 Ответ на коммантарий: <code>{commenter.answer_prompt}</code>

<b>🔗 Нейропостинг</b>
🔔 Перефразирование поста: <code>{poster.prompt}</code>""",
            reply_markup=builder.as_markup(),
        )
        await call.answer("✅ Успешно")
