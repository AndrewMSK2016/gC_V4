from aiogram import F, Router
from aiogram.types import CallbackQuery, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sqlalchemy.orm import create_session

from database import engine, Channel, CommenterSettings, PosterSettings
from .add_channel import list_channels


router = Router()


@router.callback_query(F.data.startswith("chinf_"))
async def channel_info(call: CallbackQuery):
    channel_id = int(call.data.split("_")[1])

    session = create_session(bind=engine)
    channel = session.get(Channel, channel_id)
    commenter = session.get(CommenterSettings, channel_id)
    poster = session.get(PosterSettings, channel_id)
    session.close()

    builder = InlineKeyboardBuilder()
    if channel.enabled:
        builder.row(
            InlineKeyboardButton(
                text=f"📵 Выключить", callback_data=f"chenabled_{channel_id}"
            ),
        )
    else:
        builder.row(
            InlineKeyboardButton(
                text=f"📳 Включить", callback_data=f"chenabled_{channel_id}"
            ),
        )
    builder.row(
        InlineKeyboardButton(
            text=f"🙃 Изменить режим работы", callback_data=f"chmode_{channel_id}"
        ),
    )
    builder.row(
        InlineKeyboardButton(
            text=f"🧠 Промпты", callback_data=f"chprompts_{channel_id}"
        ),
    )
    builder.row(
        InlineKeyboardButton(
            text=f"💬 Комментинг", callback_data=f"chcomments_{channel_id}"
        ),
        InlineKeyboardButton(text=f"🚀 Постинг", callback_data=f"chposts_{channel_id}"),
    )
    builder.row(
        InlineKeyboardButton(text=f"🗑️ Удалить", callback_data=f"chdelete_{channel_id}"),
    )
    builder.row(
        InlineKeyboardButton(text=f"🏠 К каналам", callback_data=f"channels"),
    )
    # generate reply text
    base_text = f"""<b>📂 Канал #{channel_id}</b>
        
📳 Статус: <b>{'🟢 Включен' if channel.enabled else '🔴 Выключен'}</b>

🙃 Режим работы: <b>{'Комментинг' if channel.mode == "comments" else 'Постинг'}</b>

🤖 Курирующий аккаунт (внутренний ID) - <code>#{channel.account}</code>
🆔 Telegram ID: <code>{channel.channel_id}</code>

🔗 Ссылка-приглашение: {channel.channel_link}


"""

    if commenter:
        base_text += f"""<b>📈 Статистика комментирования</b>
👍 За сегодня было оставлено <b>{commenter.daily_comments} комм.</b> и <b>{commenter.daily_reply_count} ответов на комментарии</b>
"""
    if poster:
        base_text += f"""<b>📈 Статистика постинга</b>
👍 За сегодня было опубликовано <b>{poster.daily_posted} постов</b>
"""


    await call.message.edit_text(
        text=base_text + "<b>📈 Выберите действие ниже для продолжения</b>",
        reply_markup=builder.as_markup(),
    )


@router.callback_query(F.data.startswith("chenabled_"))
async def edchannel(call: CallbackQuery):
    channel_id = int(call.data.split("_")[1])
    session = create_session(engine)
    channel = session.get(Channel, channel_id)
    channel.enabled = not channel.enabled
    session.commit()
    session.close()
    await call.answer(text="✅ Успешно")
    await channel_info(call)


@router.callback_query(F.data.startswith("chmode_"))
async def change_mode(call: CallbackQuery):
    channel_id = int(call.data.split("_")[1])
    session = create_session(engine)
    channel = session.get(Channel, channel_id)
    channel.mode = "posting" if channel.mode == "comments" else "comments"
    session.commit()
    session.close()
    await call.answer(text="✅ Успешно")
    await channel_info(call)


@router.callback_query(F.data.startswith("chdelete_"))
async def request_delete_comfirm(call: CallbackQuery):
    channel_id = int(call.data.split("_")[1])
    builder = InlineKeyboardBuilder()
    builder.add(
        InlineKeyboardButton(
            text="🗑️ Удалить", callback_data=f"channeldelete_{channel_id}"
        ),
        InlineKeyboardButton(text="❌ Обратно", callback_data=f"chinf_{channel_id}"),
    )
    await call.message.edit_text(
        text="🗑️ Вы уверены, что хотите удалить канал?", reply_markup=builder.as_markup()
    )


@router.callback_query(F.data.startswith("channeldelete_"))
async def delete_channel(call: CallbackQuery):
    channel_id = int(call.data.split("_")[1])
    session = create_session(engine)
    channel = session.get(Channel, channel_id)
    commenter_settings = (
        session.query(CommenterSettings).filter_by(channel_id=channel_id).first()
    )
    poster_settings = (
        session.query(PosterSettings).filter_by(channel_id=channel_id).first()
    )
    if commenter_settings:
        session.delete(commenter_settings)
    if poster_settings:
        session.delete(poster_settings)
    session.commit()
    session.delete(channel)
    session.commit()
    session.close()
    await call.answer("🗑️ Удалено")

    await list_channels(call)
