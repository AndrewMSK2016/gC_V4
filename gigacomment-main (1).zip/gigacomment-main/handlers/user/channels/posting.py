from random import randint
from uuid import uuid4

from aiogram import Router, F, Bot
from aiogram.fsm.context import FSMContext
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    Message,
    KeyboardButton,
    KeyboardButtonRequestChat,
    ChatAdministratorRights,
    ReplyKeyboardRemove,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder, ReplyKeyboardBuilder
from sqlalchemy.orm import create_session

from database import PosterSettings, engine, Channel, Account
from states import UserStates
from config import model_names

router = Router()


async def send_poster_menu(
    call: CallbackQuery, poster: PosterSettings, state: FSMContext = None
):
    if state:
        await state.clear()
    builder = InlineKeyboardBuilder()
    builder.add(
        InlineKeyboardButton(
            text="Таргет-канал", callback_data=f"editpsett|target|{poster.id}"
        ),
        InlineKeyboardButton(
            text="Задержка поста", callback_data=f"editpsett|latency|{poster.id}"
        ),
        InlineKeyboardButton(
            text="Генерация текста к посту по первому предложению",
            callback_data=f"editpsett|generate_by_first|{poster.id}",
        ),
        InlineKeyboardButton(
            text="Использовать стоп-слова",
            callback_data=f"editpsett|user_stop_words|{poster.id}",
        ),
        InlineKeyboardButton(
            text="Изменить список стоп-слов",
            callback_data=f"editpsett|change_stop_words|{poster.id}",
        ),
        InlineKeyboardButton(
            text="Ссылка", callback_data=f"editpsett|link|{poster.id}"
        ),
        InlineKeyboardButton(
            text="Модель", callback_data=f"editpsett|model|{poster.id}"
        ),
        InlineKeyboardButton(
            text="Обратно", callback_data=f"chinf_{poster.channel_id}"
        ),
    )
    builder.adjust(1)

    await call.message.edit_text(
        text=f"""<b>🤖 Нейро-постинг</b>
        
<b>🔗 Таргет-канал</b>
🆔 ID: <code>{poster.to_channel_id}</code>
🔗 Ссылка на канал: <code>{poster.to_channel_link}</code>

<b>⚙️ Настройки нейропостинга</b>
🕝 Задержка поста: <code>{poster.latency}</code>
📂 Генерация текста к посту по первому предложению: <code>{'🟢 Да' if poster.generate_by_first else '🛑 Нет'}</code>
💥 Использовать стоп-слова: <code>{'🟢 Да' if poster.user_stop_words else '🛑 Нет'}</code>
🔗 Ссылка: <code>{poster.link}</code>
🤖 Используемая модель: <b>{model_names[poster.model]}</b>

⛔ Стоп слова: <code>{"; ".join(poster.stop_words)}</code>

<b>📈 Статистика</b>
⏳ За день оставлено постов: <code>{poster.daily_posted} шт.</code>
⏳ За все время оставлено постов: <code>{poster.posted_count} шт.</code>

<i>🧠 Для изменения промптов перейдите в меню канала и выберите пункт "Промпты"</i>

<b>⚠️ Для изменения параметров используйте клавиатуру ниже</b>
    """,
        reply_markup=builder.as_markup(),
    )


async def send_messaged_poster_menu(message: Message, poster: PosterSettings):
    builder = InlineKeyboardBuilder()
    builder.add(
        InlineKeyboardButton(
            text="Таргет-канал", callback_data=f"editpsett|target|{poster.id}"
        ),
        InlineKeyboardButton(
            text="Задержка поста", callback_data=f"editpsett|latency|{poster.id}"
        ),
        InlineKeyboardButton(
            text="Генерация текста к посту по первому предложению",
            callback_data=f"editpsett|generate_by_first|{poster.id}",
        ),
        InlineKeyboardButton(
            text="Использовать стоп-слова",
            callback_data=f"editpsett|user_stop_words|{poster.id}",
        ),
        InlineKeyboardButton(
            text="Изменить список стоп-слов",
            callback_data=f"editpsett|change_stop_words|{poster.id}",
        ),
        InlineKeyboardButton(
            text="Ссылка", callback_data=f"editpsett|link|{poster.id}"
        ),
        InlineKeyboardButton(
            text="Модель", callback_data=f"editpsett|model|{poster.id}"
        ),
        InlineKeyboardButton(
            text="Обратно", callback_data=f"chinf_{poster.channel_id}"
        ),
    )
    builder.adjust(1)

    await message.answer(
        text=f"""<b>🤖 Нейро-постинг</b>
        
<b>🔗 Таргет-канал</b>
🆔 ID: <code>{poster.to_channel_id}</code>
🔗 Ссылка на канал: <code>{poster.to_channel_link}</code>

<b>⚙️ Настройки нейропостинга</b>
🕝 Задержка поста: <code>{poster.latency}</code>
📂 Генерация текста к посту по первому предложению: <code>{'🟢 Да' if poster.generate_by_first else '🛑 Нет'}</code>
💥 Использовать стоп-слова: <code>{'🟢 Да' if poster.user_stop_words else '🛑 Нет'}</code>
🔗 Ссылка: <code>{poster.link}</code>
🤖 Используемая модель: <b>{model_names[poster.model]}</b>

⛔ Стоп слова: <code>{"; ".join(poster.stop_words)}</code>

<i>🧠 Для изменения промптов перейдите в меню канала и выберите пункт "Промпты"</i>

<b>⚠️ Для изменения параметров используйте клавиатуру ниже</b>
        """,
        reply_markup=builder.as_markup(),
    )


@router.callback_query(F.data.startswith("chposts_"))
@router.callback_query(F.data.startswith("cancelposting_"))
async def posting_menu(call: CallbackQuery):
    channel_id = int(call.data.split("_")[1])

    session = create_session(engine)
    poster = session.query(PosterSettings).filter_by(channel_id=channel_id).first()
    if not poster:
        poster = PosterSettings(channel_id=channel_id, stop_words=[])
        session.add(poster)
        session.commit()
    session.close()

    await send_poster_menu(call, poster)


@router.callback_query(F.data.startswith("editpsett|"))
async def edit_posting(call: CallbackQuery, state: FSMContext):
    action, poster_id = call.data.split("|")[1], int(call.data.split("|")[2])

    session = create_session(bind=engine)
    poster = session.get(PosterSettings, poster_id)

    cancel_builder = InlineKeyboardBuilder()
    cancel_builder.row(
        InlineKeyboardButton(
            text="❌ Отмена", callback_data=f"cancelposting_{poster.channel_id}"
        )
    )

    if action == "user_stop_words":
        poster.user_stop_words = not poster.user_stop_words
        session.commit()
        session.close()
        await send_poster_menu(call, poster)
    elif action == "change_stop_words":
        await state.set_state(UserStates.ENTER_POSTING_STOP_WORDS)
        await state.update_data(id=poster_id)
        await call.message.edit_text(
            text=f"""<b>⛔ Изменение стоп-слов</b>
            
📝 Введите стоп-слова, каждое слово должно разделяться <b>запятой</b>

💠 Текущие стоп-слова (для копирования нажмите на них): <code>{", ".join(poster.stop_words)}</code>

💡 Пример: <code>не могу говорить на эту тему, еще одно стоп слово, тест</code>""",
            reply_markup=cancel_builder.as_markup(),
        )
    elif action == "generate_by_first":
        poster.generate_by_first = not poster.generate_by_first
        session.commit()
        session.close()
        await send_poster_menu(call, poster)
    elif action == "latency":
        await state.update_data(id=poster_id)
        await state.set_state(UserStates.ENTER_POSTING_LATENCY)
        await call.message.edit_text(
            text=f"""<b>🕝 Введите новую задержку</b>
            
🎼 Она должна быть в формате 5-10, где 5: минимальное кол-во минут, а 10: максимальное
Также Вы можете ввести фиксированное количество минут задержки.

<b>⚠️ Задержка может быть от 5 минут до 1 часа</b>""",
            reply_markup=cancel_builder.as_markup(),
        )
    elif action == "link":
        await state.update_data(id=poster_id)
        await call.message.edit_text(
            text=f"""<b>🔗 Введите новую ссылку</b>
            
💡 На самом деле, это просто то, что будет вставляться в конце поста. Можете оформить в качестве гиперссылки, бот тоже это обработает спокойно""",
            reply_markup=cancel_builder.as_markup(),
        )
        await state.set_state(UserStates.ENTER_POSTING_LINK)
    elif action == "target":
        await state.update_data(id=poster_id)
        await call.message.edit_text(
            text=f"""<b>🔗 Добавьте бота в админы нужного канала, а затем выберите его по кнопке ниже</b>
            
<b>⚠️ Важно. Выдайте боту только право "писать сообщения" в канале</b>""",
            reply_markup=cancel_builder.as_markup(),
        )
        builder = ReplyKeyboardBuilder()
        builder.row(
            KeyboardButton(
                text="Вот сюда нажмите",
                request_chat=KeyboardButtonRequestChat(
                    bot_administrator_rights=ChatAdministratorRights(
                        can_post_messages=True,
                        can_change_info=False,
                        can_delete_messages=False,
                        can_invite_users=False,
                        can_manage_chat=False,
                        can_manage_video_chats=False,
                        can_promote_members=False,
                        can_restrict_members=False,
                        is_anonymous=True,
                    ),
                    bot_is_member=True,
                    chat_is_channel=True,
                    request_id=randint(0, 9999999),
                    user_administrator_rights=ChatAdministratorRights(
                        can_post_messages=True,
                        can_change_info=True,
                        can_delete_messages=True,
                        can_invite_users=True,
                        can_manage_chat=True,
                        can_manage_video_chats=True,
                        can_promote_members=True,
                        can_restrict_members=True,
                        is_anonymous=True,
                    ),
                ),
            )
        )
        await call.message.answer(
            text="ㅤ", reply_markup=builder.as_markup(resize_keyboard=True)
        )
        await state.set_state(UserStates.ENTER_POSTING_TARGET)
    elif action == "model":
        poster.model = "chatgpt" if poster.model == "gigachat" else "gigachat"
        session.commit()
        session.close()
        await call.answer("✅ Изменено")
        return await send_poster_menu(call, poster)


@router.message(UserStates.ENTER_POSTING_STOP_WORDS)
async def apply_stop_words(message: Message, state: FSMContext):
    data = await state.get_data()
    await state.clear()

    poster_id = int(data.get("id"))
    session = create_session(engine)
    poster = session.get(PosterSettings, poster_id)
    poster.stop_words = message.text.split(", ")
    session.commit()
    session.close()
    await send_messaged_poster_menu(message, poster)


@router.message(UserStates.ENTER_POSTING_TARGET)
async def join_to_target(message: Message, state: FSMContext):
    data = await state.get_data()
    await state.clear()

    session = create_session(engine)
    poster = session.get(PosterSettings, data["id"])
    poster.to_channel_link = message.text
    session.commit()
    session.close()

    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text="✅ Выдал",
            callback_data=f"chptgt_{poster.id}_{message.chat_shared.chat_id}",
        )
    )
    await message.answer(
        text=f"""<b>👍 Отлично! Остался последний шаг!</b>
        
🔗 Теперь добавьте этого бота как админа в канале <code>#{message.chat_shared.chat_id}</code>. Как только закончите, возвращайтесь сюда и нажмите на кнопку ниже для продолжения""",
        reply_markup=builder.as_markup(),
    )


@router.callback_query(F.data.startswith("chptgt_"))
async def check_and_commit(call: CallbackQuery, bot: Bot):
    poster_id = int(call.data.split("_")[1])
    channel_id = int(call.data.split("_")[2])
    chat = await bot.get_chat(channel_id)
    if not chat:
        return await call.answer(
            text="❌ Вы не добавили бота в канал.", show_alert=True
        )
    session = create_session(engine)
    poster = session.get(PosterSettings, poster_id)
    poster.to_channel_link = chat.invite_link
    poster.to_channel_id = chat.id
    session.commit()
    session.close()
    msg = await call.message.answer(text="ㅤ", reply_markup=ReplyKeyboardRemove())
    await msg.delete()
    return await send_poster_menu(call, poster)


@router.message(UserStates.ENTER_POSTING_LINK)
async def apply_posting_link(message: Message, state: FSMContext):
    data = await state.get_data()
    await state.clear()

    session = create_session(engine)
    poster = session.get(PosterSettings, data["id"])
    poster.link = message.html_text
    session.commit()
    session.close()
    await message.answer("✅ Успешно")
    await send_messaged_poster_menu(message, poster)


@router.message(UserStates.ENTER_POSTING_LATENCY)
async def apply_posting(message: Message, state: FSMContext):
    data = await state.get_data()
    session = create_session(engine)
    poster = session.get(PosterSettings, data["id"])
    builder = InlineKeyboardBuilder()
    builder.add(
        InlineKeyboardButton(
            text="❌ Отмена", callback_data=f"cancelposting_{data['id']}"
        )
    )
    try:
        min_lat, max_lat = map(int, message.text.split("-"))
        if min_lat > max_lat or min_lat < 5 or max_lat < 0 or max_lat > 60:
            session.close()
            return await message.answer(
                text="<b>❌ Неверный формат ввода</b>", reply_markup=builder.as_markup()
            )
        poster.latency = f"{min_lat}-{max_lat}"
    except:
        if not message.text.isdigit() or int(message.text) < 0:
            session.close()
            return await message.answer(
                text="<b>❌ Неверный формат ввода</b>", reply_markup=builder.as_markup()
            )
        else:
            poster.latency = int(message.text)
    session.commit()
    await message.answer("✅ Успешно")
    await send_messaged_poster_menu(message, poster)
