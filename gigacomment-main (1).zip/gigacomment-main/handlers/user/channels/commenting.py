from aiogram import Router, F
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sqlalchemy.orm import create_session

from database import engine, User, CommenterSettings
from states import UserStates
from config import model_names

router = Router()


async def show_commenting(call: CallbackQuery, comm_settings: CommenterSettings):
    builder = InlineKeyboardBuilder()
    builder.add(
        InlineKeyboardButton(
            text="Задержка комментария",
            callback_data=f"editcsett|latency|{comm_settings.id}",
        ),
        InlineKeyboardButton(
            text="Вероятность комментирования",
            callback_data=f"editcsett|random|{comm_settings.id}",
        ),
        InlineKeyboardButton(
            text="Комментировать короткие посты",
            callback_data=f"editcsett|only_react_short_posts|{comm_settings.id}",
        ),
        InlineKeyboardButton(
            text="Отвечать на комментарии",
            callback_data=f"editcsett|answer_replies|{comm_settings.id}",
        ),
        InlineKeyboardButton(
            text="Модель", callback_data=f"editcsett|model|{comm_settings.id}"
        ),
        InlineKeyboardButton(
            text="Обратно", callback_data=f"chinf_{comm_settings.channel_id}"
        ),
    )
    builder.adjust(1)
    await call.message.edit_text(
        text=f"""<b>🧠 Настройки комментирования</b>

⏰ Задержка комментария: <code>{comm_settings.latency} сек.</code>
🍀 Вероятность комментирования: <code>{comm_settings.random}</code> (1 - мин; 3 - макс)
🤖 Отвечать на комментарии: <code>{'🟢 Да' if comm_settings.answer_replies else '🛑 Нет'}</code>
🔔 Комментировать короткие посты: <code>{'🟢 Да' if comm_settings.only_react_short_posts else '🛑 Нет'}</code>
🤖 Используемая модель: <b>{model_names[comm_settings.model]}</b>

<b>📈 Статистика</b>
⏳ За день оставлено комментариев: <code>{comm_settings.daily_comments} шт.</code>
⏳ За все время оставлено комментариев: <code>{comm_settings.comments_count} шт.</code>


<i>🧠 Для изменения промптов перейдите в меню канала и выберите пункт "Промпты"</i>

<b>⚠️ Для изменения параметров используйте клавиатуру ниже</b>""",
        reply_markup=builder.as_markup(),
    )


@router.callback_query(F.data.startswith("chcomments_"))
async def show_comments_menu(call: CallbackQuery, state: FSMContext):
    await state.clear()
    channel_id = int(call.data.split("_")[1])
    session = create_session(engine)
    comm_settings = (
        session.query(CommenterSettings).filter_by(channel_id=channel_id).first()
    )
    if not comm_settings:
        comm_settings = CommenterSettings(channel_id=channel_id)
        session.add(comm_settings)
        session.commit()
    session.close()

    await show_commenting(call, comm_settings)


@router.callback_query(F.data.startswith("editcsett|"))
async def edit_commencts_settings(call: CallbackQuery, state: FSMContext):
    action, comm_id = call.data.split("|")[1], int(call.data.split("|")[2])
    session = create_session(engine)
    comm_settings = session.get(CommenterSettings, comm_id)

    if action == "only_react_short_posts":
        comm_settings.only_react_short_posts = not comm_settings.only_react_short_posts
        session.commit()
        session.close()
        await call.answer("✅ Успешно")
        return await show_commenting(call, comm_settings)
    elif action == "answer_replies":
        comm_settings.answer_replies = not comm_settings.answer_replies
        session.commit()
        session.close()
        await call.answer("✅ Успешно")
        return await show_commenting(call, comm_settings)
    elif action == "latency":
        await state.set_state(UserStates.ENTER_COMMENT_LATENCY)
        builder = InlineKeyboardBuilder()
        builder.add(
            InlineKeyboardButton(
                text="❌ Отмена", callback_data=f"chcomments_{comm_settings.id}"
            )
        )
        await call.message.edit_text(
            text=f"""<b>🕝 Введите новую задержку</b>
            
🎼 Она должна быть в формате 5-10, где 5: минимальное кол-во секунд, а 10: максимальное
Также Вы можете ввести фиксированное количество секунд задержки""",
            reply_markup=builder.as_markup(),
        )
        await state.set_data({"id": comm_settings.id})
    elif action == "random":
        if comm_settings.random in [1, 2]:
            comm_settings.random += 1
        else:
            comm_settings.random = 1
        session.commit()
        session.close()
        await call.answer("✅ Успешно")
        return await show_commenting(call, comm_settings)
    elif action == "model":
        comm_settings.model = (
            "chatgpt" if comm_settings.model == "gigachat" else "gigachat"
        )
        session.commit()
        session.close()
        await call.answer("✅ Изменено")
        return await show_commenting(call, comm_settings)


@router.message(UserStates.ENTER_COMMENT_LATENCY)
async def apply_comment_latency(msg: Message, state: FSMContext):
    data = await state.get_data()
    session = create_session(engine)
    comm_settings = session.get(CommenterSettings, data["id"])
    builder = InlineKeyboardBuilder()
    builder.add(
        InlineKeyboardButton(text="❌ Отмена", callback_data=f"chcomments_{data['id']}")
    )
    try:
        min_lat, max_lat = map(int, msg.text.split("-"))
        if min_lat > max_lat or min_lat < 0 or max_lat < 0:
            session.close()
            return await msg.answer(
                text="<b>❌ Неверный формат ввода</b>", reply_markup=builder.as_markup()
            )
        comm_settings.latency = f"{min_lat}-{max_lat}"
    except:
        if not msg.text.isdigit() or int(msg.text) < 0:
            session.close()
            return await msg.answer(
                text="<b>❌ Неверный формат ввода</b>", reply_markup=builder.as_markup()
            )
        else:
            comm_settings.latency = int(msg.text)
    session.commit()
    await msg.answer("✅ Успешно")
    builder = InlineKeyboardBuilder()
    builder.add(
        InlineKeyboardButton(
            text="Задержка комментария",
            callback_data=f"editcsett|latency|{comm_settings.id}",
        ),
        InlineKeyboardButton(
            text="Вероятность комментирования",
            callback_data=f"editcsett|random|{comm_settings.id}",
        ),
        InlineKeyboardButton(
            text="Комментировать короткие посты",
            callback_data=f"editcsett|only_react_short_posts|{comm_settings.id}",
        ),
        InlineKeyboardButton(
            text="Отвечать на комментарии",
            callback_data=f"editcsett|answer_replies|{comm_settings.id}",
        ),
        InlineKeyboardButton(
            text="Модель", callback_data=f"editcsett|model|{comm_settings.id}"
        ),
        InlineKeyboardButton(text="Обратно", callback_data=f"chinf_{comm_settings.id}"),
    )
    builder.adjust(1)
    await msg.answer(
        text=f"""<b>🧠 Настройки комментирования</b>

⏰ Задержка комментария: <code>{comm_settings.latency} сек.</code>
🍀 Вероятность комментирования: <code>{comm_settings.random}</code> (1 - мин; 3 - макс)
🤖 Отвечать на комментарии: <code>{'🟢 Да' if comm_settings.answer_replies else '🛑 Нет'}</code>
🔔 Комментировать короткие посты: <code>{'🟢 Да' if comm_settings.only_react_short_posts else '🛑 Нет'}</code>
🤖 Используемая модель: <b>{model_names[comm_settings.model]}</b>

<i>🧠 Для изменения промптов перейдите в меню канала и выберите пункт "Промпты"</i>

<b>⚠️ Для изменения параметров используйте клавиатуру ниже</b>""",
        reply_markup=builder.as_markup(),
    )
