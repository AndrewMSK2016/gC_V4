import re
from typing import List

from aiogram import Bot, Router, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, InputMediaPhoto, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sqlalchemy.orm import create_session
from aiogram_media_group import media_group_handler

from handlers.user.accounts.userbot_actions import send_msg_to_user
from states import UserStates
from utils import prepare_userbots_ids
from database import PosterSettings, engine, Channel, Account
from userbot.gigachat import Gigachat
from userbot.funcs import send_notification
from config import config


router = Router()

sent_mediagroups = []


@router.message(Command("newpm"))
async def new_pm(message: Message, state: FSMContext):
    parts = message.text.split()
    await state.set_state(UserStates.ENTER_RESEND_MESSAGE_FROM_USERBOT)
    await state.update_data(user_id=parts[2], account_id=parts[1])


@router.message(UserStates.ENTER_RESEND_MESSAGE_FROM_USERBOT)
async def resend_message(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    await state.clear()

    session = create_session(engine)
    account = session.get(Account, data["account_id"])
    session.close()

    builder = InlineKeyboardBuilder()
    builder.add(
        InlineKeyboardButton(
            text="📧 Ответить",
            callback_data=f"answerpm|{data['account_id']}|{data['user_id']}|{message.from_user.id}",
        )
    )
    await bot.send_message(
        chat_id=account.user,
        text=f"""<b>🔔 Новое сообщение!</b>

🧳 Вашему юзерботу #{account.id} написали новое сообщение. Выберите действие по кнопкам ниже.

Ах и да, само сообщение можно увидеть ниже ⬇️⬇️⬇️""",
        reply_markup=builder.as_markup(),
    )
    await message.forward(chat_id=account.user)


#@router.message()
async def handle_userbot_messages(message: Message, bot: Bot, state: FSMContext):
    if await state.get_state() == UserStates.ENTER_USERBOT_REPLY:
        return await send_msg_to_user(message, state, bot)
    userbots = prepare_userbots_ids()
    if message.from_user.id in userbots:
        print("Handle userbot!")
        message_type, channel_id, original_text = (
            message.text.split("|==|")
            if message.text
            else message.caption.split("|==|")
        )
        channel_id = int(channel_id)
        session = create_session(engine)
        poster_settings = (
            session.query(PosterSettings).filter_by(channel_id=channel_id).first()
        )
        channel = session.get(Channel, poster_settings.channel_id)
        account = session.get(Account, channel.account)
        session.close()

        print("Got settings")
        if poster_settings.model == "gigachat":
            gigachat = Gigachat()
            await gigachat.auth(
                client_id=config.gigachat.client_id,
                client_secret=config.gigachat.client_secret,
            )
            text = await gigachat.get_answer(
                prompt=poster_settings.prompt.format(original_text)
            )
        else:
            text = (
                config.chatgpt.completions.create(
                    model="gpt-3.5-turbo",
                    messages=[{"role": "user", "content": original_text}],
                )
                .choices[0]
                .message.content
            )
        print("Got answer")
        if not poster_settings.user_stop_words:
            for stop_word in poster_settings.stop_words:
                if stop_word.lower() in original_text.lower():
                    await send_notification(
                        account_id=account.file_id,
                        text=f"""<b>🔔 Новое сообщение от постера</b>

❌ <b>Не удалось</b> переслать сообщение из канала {channel.channel_link} в канал {poster_settings.to_channel_link}, поскольку содержит запрещенное слово: <b>{stop_word}</b>

💠 Исходное сообщение: <blockquote>{original_text}</blockquote>

📝 <b>Само сообщение с запрещенными словами:</b> <blockquote>{text}</blockquote>""",
                    )
                    return

        if poster_settings.link:
            text += "\n\n" + poster_settings.link

        # todo: implement user notification
        if message_type == "text":
            try:
                await bot.send_message(
                    chat_id=poster_settings.to_channel_id, text=text, parse_mode="HTML"
                )
                await send_notification(
                    account_id=account.file_id,
                    text=f"""<b>🔔 Новое сообщение от постера</b>

✅ <b>Успешно</b> опубликовано сообщение из канала {channel.channel_link} в канал {poster_settings.to_channel_link}

💠 Исходное сообщение: <blockquote>{original_text}</blockquote>

📝 <b>Сгенерированное сообщение:</b> <blockquote>{text}</blockquote>""",
                )

                # increase the counter
                session = create_session(engine)
                poster_settings = (
                    session.query(PosterSettings)
                    .filter_by(channel_id=channel_id)
                    .first()
                )
                poster_settings.posted_count += 1
                poster_settings.daily_posted += 1
                session.commit()
                session.close()
            except Exception as e:
                await send_notification(
                    account_id=account.file_id,
                    text=f"""<b>🔔 Новое сообщение от постера</b>

 ❌ <b>Не удалось</b> переслать сообщение из канала {channel.channel_link} в канал {poster_settings.to_channel_link}
 
💠 Исходное сообщение: <blockquote>{original_text}</blockquote>

📝 <b>Сгенерированное сообщение:</b> <blockquote>{text}</blockquote>

⚠️ Если вы считаете, что ошибка на нашей стороне, отправьте нам этот текст: <code>{str(e)}</code>""",
                )

        elif message_type == "photo":
            try:
                await bot.send_photo(
                    chat_id=poster_settings.to_channel_id,
                    caption=text,
                    photo=message.photo[-1].file_id,
                )
                await send_notification(
                    account_id=account.file_id,
                    text=f"""<b>🔔 Новое сообщение от постера</b>

✅ <b>Успешно</b> опубликовано сообщение из канала {channel.channel_link} в канал {poster_settings.to_channel_link}

💠 Исходное сообщение: <blockquote>{original_text}</blockquote>

📝 <b>Сгенерированное сообщение:</b> <blockquote>{text}</blockquote>""",
                )

                # increase the counter
                session = create_session(engine)
                poster_settings = (
                    session.query(PosterSettings)
                    .filter_by(channel_id=channel_id)
                    .first()
                )
                poster_settings.posted_count += 1
                poster_settings.daily_posted += 1
                session.commit()
                session.close()
            except Exception as e:
                await send_notification(
                    account_id=account.file_id,
                    text=f"""<b>🔔 Новое сообщение от постера</b>

❌ <b>Не удалось</b> переслать сообщение из канала {channel.channel_link} в канал {poster_settings.to_channel_link}

💠 Исходное сообщение: <blockquote>{original_text}</blockquote>

📝 <b>Сгенерированное сообщение:</b> <blockquote>{text}</blockquote>

⚠️ Если вы считаете, что ошибка на нашей стороне, отправьте нам этот текст: <code>{str(e)}</code>""",
                )


@router.message(lambda m: m.media_group_id and m.from_user.id in prepare_userbots_ids())
@media_group_handler
async def mediagroup_resend(message: Message, media_events: List[Message]):
    print("Handle userbot mediagroup!")
    message_type, channel_id, original_text = message.caption.split("|==|")
    channel_id = int(channel_id)
    session = create_session(engine)
    poster_settings = (
        session.query(PosterSettings).filter_by(channel_id=channel_id).first()
    )
    channel = session.get(Channel, poster_settings.channel_id)
    account = session.get(Account, channel.account)

    if poster_settings.generate_by_first:
        text = original_text.split(".")[0]
    gigachat = Gigachat()
    token = await gigachat.auth(
        client_id=config.gigachat.client_id, client_secret=config.gigachat.client_secret
    )
    text = await gigachat.get_answer(
        prompt=poster_settings.prompt.format(original_text)
    )
    if not poster_settings.user_stop_words and poster_settings.stop_words:
        for stop_word in poster_settings.stop_words:
            if stop_word.lower() in original_text.lower():
                await send_notification(
                    account_id=account.file_id,
                    text=f"""<b>🔔 Новое сообщение от постера</b>
                
❌ <b>Не удалось</b> переслать сообщение из канала {channel.channel_link} в канал {poster_settings.to_channel_link}, поскольку содержит запрещенное слово: <b>{stop_word}</b>

💠 Исходное сообщение: <blockquote>{original_text}</blockquote>

📝 <b>Само сообщение с запрещенными словами:</b> <blockquote>{text}</blockquote>""",
                )
                return

    if poster_settings.link:
        text += "\n\n" + poster_settings.link
    if message_type == "mediagroup":
        photos = [message.photo[-1] for message in media_events]
        try:
            media_group = []
            for photo in photos:
                media_group.append(InputMediaPhoto(media=photo.file_id))
            await message.bot.send_media_group(
                chat_id=poster_settings.to_channel_id, media=[s.file_id for s in photos]
            )
            await send_notification(
                account_id=account.file_id,
                text=f"""<b>🔔 Новое сообщение от постера</b>
                
✅ <b>Успешно</b> опубликовано сообщение из канала {channel.channel_link} в канал {poster_settings.to_channel_link}

💠 Исходное сообщение: <blockquote>{original_text}</blockquote>

📝 <b>Сгенерированное сообщение:</b> <blockquote>{text}</blockquote>""",
            )

            # increase the counter
            session = create_session(engine)
            poster_settings = (
                session.query(PosterSettings).filter_by(channel_id=channel_id).first()
            )
            poster_settings.posted_count += 1
            poster_settings.daily_posted += 1
            session.commit()
            session.close()
        except Exception as e:
            await send_notification(
                account_id=account.file_id,
                text=f"""<b>🔔 Новое сообщение от постера</b>
                
❌ <b>Не удалось</b> переслать сообщение из канала {channel.channel_link} в канал {poster_settings.to_channel_link}

💠 Исходное сообщение: <blockquote>{original_text}</blockquote>

📝 <b>Сгенерированное сообщение:</b> <blockquote>{text}</blockquote>

⚠️ Если вы считаете, что ошибка на нашей стороне, отправьте нам этот текст: <code>{str(e)}</code>""",
            )
